#ifndef __COND_INI_HXX
#define __COND_INI_HXX

#include <cmath>

inline double cond_ini(double x, double y, double z)
{
  x -= 0.5;
  y -= 0.5;
  z -= 0.5;
  double r = x * x + y * y + z * z;
  if (r < 0.1)
    return exp(-r);
  else
    return 0.0;
}

#endif

