#include <cmath>

#ifndef __FORCE_HXX
#define __FORCE_HXX

inline double force(double x, double y, double z, double t)
{
  x -= 0.7;
  y -= 0.5;
  z -= 0.5;
  double f, r = x * x + y * y + z * z;
  if (r < 0.1)
    f = sin(x) * cos(y) * exp(-z * z);
  else
    f = 0.5;

  return f;
}

#endif
