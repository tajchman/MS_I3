#include <vector>

void init(std::vector<double> & u);
