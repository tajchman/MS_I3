#include "init.hxx"
#include "calcul.hxx"
#include <iostream>
#include <vector>
#include <cmath>
#include <unistd.h>

#include "arguments.hxx"

double f(double a, double x)
{
  usleep(100);
  return sin(a*x);
}

int main(int argc, char **argv) {

  Arguments Args(argc, argv);
  size_t n = Args.Get("n", 10000L);

  std::vector<double> u(n), v_seq(n, 0);
  double a = M_PI;

  init(u);

  calcul_seq (v_seq, a, f, u);
   
  return 0;
 }
