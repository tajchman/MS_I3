#! /usr/bin/env python

import subprocess, os

for i in range(1,4):
    e = os.environ.copy()
    cmd = './install/ex_4_' + str(i)

    for t in ['1', '3']:
       e['OMP_NUM_THREADS'] = t
       print('OMP_NUM_THREADS=' + t + ' ' + cmd)
       subprocess.call(cmd, env=e)


