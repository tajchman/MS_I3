#include <iostream>
#include <cstdlib>
#include <time.h>
#include <cstring>
#ifdef _OPENMP
#include <omp.h>
#endif

#include "results.hxx"
#include "timer.hxx"
#include "binary.hxx"

int main(int argc, char **argv) {

  Timer T_total, T_init, T_calcul;
  T_total.start();
  T_init.start();
  
  size_t i, n;
  double *u;
  readVector("data.bin", u, n);

  int nThreads;

  #ifdef _OPENMP
  #pragma omp parallel
  {
    #pragma omp master
    nThreads = omp_get_num_threads();
  }
  #else
    nThreads = 1;
  #endif

  std::cerr << "version 4, " << nThreads << " thread(s)"
            << " n = " << n << " u0 = " << u[0] << " ";

  double moy, var;

  T_init.stop();
  T_calcul.start();

  double s = 0, s2 = 0;

  #pragma omp parallel for default(shared) reduction(+: s, s2)
  for (i=0; i<n ; i++) {
    s += u[i];
    s2 += u[i]*u[i];
  }

  delete [] u;
  moy = s / n;
  var = s2/n - moy*moy;

  T_calcul.stop();

  T_total.stop();

  writeResults("version4", n, nThreads, moy, var, 
                T_init.elapsed(), T_calcul.elapsed(), T_total.elapsed());
  return 0;
}
