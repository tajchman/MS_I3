#ifndef __RESULTS_HXX
#define __RESULTS_HXX

void writeResults(const char *version, int n, int nThreads, 
                  double moy, double var, 
                  double t_init, double t_calcul, double t_total);

#endif