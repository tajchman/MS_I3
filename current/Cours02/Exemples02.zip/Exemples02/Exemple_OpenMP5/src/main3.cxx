#include <iostream>
#include <cstdlib>
#include <time.h>
#ifdef _OPENMP
#include <omp.h>
#endif
#include <cstring>

#include "timer.hxx"
#include "results.hxx"
#include "binary.hxx"

int main(int argc, char **argv) {

  Timer T_total, T_init, T_calcul;
  T_total.start();
  T_init.start();

  size_t i, n;
  double *u;
  readVector("data.bin", u, n);

  int nThreads;

  #ifdef _OPENMP
  #pragma omp parallel
  {
    #pragma omp master
    nThreads = omp_get_num_threads();
  }
  #else
    nThreads = 1;
  #endif

  std::cerr << "version 3, " << nThreads << " thread(s)"
            << " n = " << n << " u0 = " << u[0] << " ";

  double moy, var;

  T_init.stop();
  T_calcul.start();

  double s = 0 , s_partiel ;
  double s2 = 0 , s2_partiel ;

  # pragma omp parallel default(shared) private ( s_partiel , s2_partiel )
  {
    s_partiel = 0.0; s2_partiel = 0.0;
  
    # pragma omp for
    for (i =0; i<n ; i++) {
      s_partiel += u[i];
      s2_partiel += u[i]*u[i];
    }

    #pragma omp atomic
      s += s_partiel; 
    #pragma omp atomic
      s2 += s2_partiel; 
  }

  delete [] u;
  moy = s / n ; 
  var = s2 /n - moy * moy ;

  T_calcul.stop();

  T_total.stop();

  writeResults("version3", n, nThreads, moy, var, 
                T_init.elapsed(), T_calcul.elapsed(), T_total.elapsed());
  return 0;
}
