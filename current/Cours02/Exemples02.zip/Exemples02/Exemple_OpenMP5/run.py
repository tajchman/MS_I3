#! /usr/bin/env python

import subprocess, os, argparse, json

res = []
n_default = 5000000000
offset_default = 1

parser = argparse.ArgumentParser()
parser.add_argument('-n', type=int, default=n_default)
parser.add_argument('--offset', type=int, default=offset_default)
parser.add_argument('-t', type=int, default=3)
args = parser.parse_args()

cmd = ['./install/init', '-n', str(args.n)]
subprocess.call(cmd)

p = {}
with open('results.json', 'w') as fOut:
    fOut.write('{\n\"results\" : [\n')
    for i in ['0', '1', '2', '2b', '3', '4']:
        p['version' + i] = {}

        e = os.environ.copy()
        ex = './install/ex_2_openmp5_' + i

        res = ['{:>16}'.format(os.path.basename(ex))]
        if i== '0':
          lt = [1]
        else:
          lt = [1, args.t]
          
        for t in lt:
            p['version' + i][t] = []

            cmd = [ex]
            if i == '2':
                cmd.append(str(args.offset))

            e['OMP_NUM_THREADS'] = str(t)

            subprocess.call(cmd, env=e)

            with open('version' + i + '_' + str(t) + '.json') as fIn:
                s = fIn.read()
                fOut.write(s)
            if i == '4' and t == args.t:
                fOut.write('\n')
            else:
                fOut.write(',\n')        
    fOut.write(']\n}\n')

with open('results.json') as fIn:
    s = json.load(fIn)

r = s['results']
for l in r:
    v = l['version']
    th = int(l['threads'])
    t = l['temps']
    p[v][th] = float(t['calcul'])

print("\ncas            1 thread      " + str(args.t) + " threads      speedup\n");

ks = list(p.keys())
ks.sort()

t_seq = -1.0
for k in ks:
    t1 = p[k][1]
    if args.t in p[k]:
      tn = p[k][args.t]
      print("{:>10s} {:>12.3g} s {:>12.3g} s {:>10.2f}".format(k, t1, tn, t_seq/tn))
    else:
      t_seq = t1
      print("{:>10s} {:>12.3g} s {:>12s} s {:>10s}".format(k, t1, " ", " "))
