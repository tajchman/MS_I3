#ifndef _OS_HXX
#define _OS_HXX

#include <sys/stat.h>

bool fileExists(const std::string & fileName);

#endif
