
void calcul1(double *y, 
             double a, 
             const double *x, 
             double b,
             int n);

void calcul2(double *y, 
             double a, 
             const double *x, 
             double b,
             int n);

