#include "Matrice.hxx"

void calcul1(Matrice &C, const Matrice &A, const Matrice &B);
void calcul2(Matrice &C, const Matrice &A, const Matrice &B);
