
void calcul(double *v, const double *u, int n, int dn);
