#include "Matrice.hxx"

void init(Matrice &C, double v0);
