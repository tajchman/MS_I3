
void calcul1(double *u, 
             double *v, 
             double *w, 
             const double *a, 
             const double *b, 
             const double *c, 
             const double *d,
             int n);

void calcul2(double *u, 
             double *v, 
             double *w, 
             const double *a, 
             const double *b, 
             const double *c, 
             const double *d,
             int n);

