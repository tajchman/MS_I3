#! /usr/bin/env python3

import os, subprocess, argparse, platform, sys

parser = argparse.ArgumentParser()
parser.add_argument('-c', '--compiler', choices=['gnu', 'intel', 'msvc'], default='gnu')
parser.add_argument('-m', '--mode', choices=['debug', 'release'], default='release')
parser.add_argument('-v', '--verbose', action='store_true')
parser.add_argument('--mpi', choices=['', 'openmpi', 'mpich'], default='')
parser.add_argument('--tests', action='store_true')
args = parser.parse_args()

base       = os.getcwd()
srcDir     = os.path.join(base, 'solution')
buildDir   = os.path.join(base, 'build_solution', args.mode)
installDir = os.path.join(base, 'install_solution', args.mode)
testDir    = os.path.join(base, 'tests')
for d in [buildDir, testDir]:
  os.makedirs(d, exist_ok=True)

e = os.environ.copy()

gen = ""
p = platform.system()
if p == 'Windows':
  gen = '-GNinja'
  if args.compiler == 'intel':
    e['CC'] = 'icx'
    e['CXX'] = 'icpx'
  else:
    e['CC'] = 'cl.exe'
    e['CXX'] = 'cl.exe'
  compileCmd = ['ninja', 'install']
elif p == 'Linux':
  gen = '-GUnix Makefiles'
  if args.compiler == 'intel':
    e['CC'] = 'icx'
    e['CXX'] = 'icpx'
  else:
    e['CC'] = 'gcc'
    e['CXX'] = 'g++'
    
configureCmd = ['cmake', gen, 
                '-B', buildDir,
                '-S', srcDir,
                '-DCMAKE_INSTALL_PREFIX=' + installDir,
                '-DCMAKE_BUILD_TYPE=' + args.mode.capitalize(),
                '-DTEST_DIR=' + testDir
                ]
if args.mpi:
  configureCmd.append('-DMPI_EXECUTABLE_SUFFIX=.' + args.mpi)

if args.verbose:
  configureCmd.append('-DCMAKE_VERBOSE_MAKEFILE:BOOL=ON')
  
compileCmd = ['cmake', '--build', buildDir]

installCmd = ['cmake', '--install', buildDir]

testCmd      = ['ctest', '--output-on-failure', '--test-dir', buildDir]

commands = [
  [configureCmd, '.'],
  [compileCmd, '.'],
  [installCmd, '.']
]
if args.tests:
  commands.append([testCmd, testDir])
  

for cmd in commands:
  if cmd == testCmd and not args.tests:
    continue
    
  print('__________________\n', ' '.join(cmd[0]), '\n', file=sys.stderr)
  err = subprocess.call(cmd[0], cwd=cmd[1], env=e)
  if not err==0:
    break 
