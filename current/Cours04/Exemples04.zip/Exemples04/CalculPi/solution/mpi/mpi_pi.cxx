#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "parameters.hxx"
#include "timer.hxx"

int main(int argc, char *argv[])
{
    int size, rank;
    double pi=0.0, partial_sum=0.0, sum=0.0, begin=0.0, end=0.0, x2;
    double d, d2;

    Parameters p(argc, argv);
    long long i, N, N1, N2;

    p.Get("n", N);

    Timer T;
    T.start();
     
    d = 1.0/N;
    d2 = d*d;

    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    begin = MPI_Wtime();

    N1 = rank * N/size;
    N2 = N1 + N/size;
    if (rank == size-1) N2 = N;
    Timer T2; T2.start();
    for (i=N1; i<N2; i++)
    {
      x2=d2*i*i;
      partial_sum+=1.0/(1.0+x2);
    }
    T2.stop();
    std::cerr << "T2 : " << T2.elapsed() << std::endl;
    
    MPI_Reduce(&partial_sum, &sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    
    end = MPI_Wtime();
    
    MPI_Finalize();

    T.stop();

    if (rank==0)
    {
      pi=4*d*sum;
      printf("Cpu time %9.3f s (%9.3f s) %2d MPI process(es)\n\n"
             "PI         =%15.10g\nPI(machine)=%15.10g\nError      =%15.2g\n", 
             T.elapsed(), end-begin, size, pi, 4*atan(1.0), fabs(4*atan(1.0)-pi));
    }

    return 0;
}
