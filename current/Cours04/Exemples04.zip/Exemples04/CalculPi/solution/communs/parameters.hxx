#ifndef _PARAMETERS_HXX
#define _PARAMETERS_HXX

#include "arguments.hxx"

class Parameters
{
public:
  Parameters(int argc, char **argv) {
    long long defaultN = 10000000000L;

    _args.add("n", defaultN, "number of points");

    #ifdef _OPENMP
    _args.add("threads", 0, "number of threads");
    #endif
  
    _args.parse(argc, argv);
  }

  template<typename T>
  void Get(const char *name, T &v) {
    _args.get(name, v);
  }
  
private:
  Arguments _args;
};


#endif
