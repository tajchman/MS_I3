#include <stdio.h>
#include <omp.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "parameters.hxx"
#include "timer.hxx"
#include "mpi.h"

int main(int argc, char *argv[])
{
    double pi=0.0, sum=0.0, x2;
    double d, d2;

    long long i, N;
    Parameters p(argc, argv);
    p.Get("n", N);
    int nThreads;
    p.Get("threads", nThreads);

    if (nThreads == 0)
    {
      char *e = getenv("OMP_NUM_THREADS");
      if (e) {
        char *end;
        nThreads = strtol(e, &end, 10);
        if (*end != '\0')
          nThreads = 1;
      }
      else {
        nThreads = 1;
      }
    }
    omp_set_num_threads(nThreads);

    Timer T;
    T.start();
     
    d = 1.0/N;
    d2 = d*d;

    int size, rank;
    const int required = MPI_THREAD_FUNNELED;
    int provided;
    MPI_Init_thread (&argc, &argv, required, &provided);
    if (provided < required)
    {
       printf("error MPI_THREAD_FUNNELED not available");
       exit(-1);
    }

    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
      
    double begin = MPI_Wtime();

    long long N1 = rank * N/size;
    long long N2 = N1 + N/size;
    if (rank == size-1) N2 = N;
    double partial_sum = 0.0;

    #pragma omp parallel for private(x2) reduction(+:partial_sum)
    for (i=N1; i<N2; i++)
    {
      x2=d2*i*i;
      partial_sum += 1.0/(1.0+x2);
    }
    
    MPI_Reduce(&partial_sum, &sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    
    double end = MPI_Wtime();
    
    MPI_Finalize();

    T.stop();

    if (rank==0)
    {
      pi=4*d*sum;
      printf("Cpu time %9.3f s (%9.3f s)\n%2d MPI process(es) %2d OpenMP thread(s)\n\n"
             "PI         =%15.10g\nPI(machine)=%15.10g\nError      =%15.2g\n", 
             T.elapsed(), end-begin, size, nThreads, pi, 4*atan(1.0), fabs(4*atan(1.0)-pi));
    }
    return 0;
}
