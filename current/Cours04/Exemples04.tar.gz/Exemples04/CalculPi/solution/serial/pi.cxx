#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "parameters.hxx"
#include "timer.hxx"

int main(int argc, char *argv[])
{
    double pi=0.0, sum=0.0, x2;
    double d, d2;

    long long i, N;
    Parameters p(argc, argv);
    p.Get("n", N);

    Timer T;
    T.start();
     
    d = 1.0/N;
    d2 = d*d;

    for (i=0; i<N; i++)
    {
        x2=d2*i*i;
        sum+=1.0/(1.0+x2);
    }
    
    T.stop();
    
    pi=4*d*sum;
    printf("Cpu time %9.3g s\n\n"
           "PI         =%15.10g\nPI(machine)=%15.10g\nError      =%15.2g\n", 
           T.elapsed(), pi, 4*atan(1.0), fabs(4*atan(1.0)-pi));
    return 0;
}
