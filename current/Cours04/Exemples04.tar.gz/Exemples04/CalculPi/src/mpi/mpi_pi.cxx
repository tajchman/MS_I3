#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "parameters.hxx"
#include "timer.hxx"

int main(int argc, char *argv[])
{
    int size, rank;
    double pi=0.0, sum=0.0, x2;
    double d, d2;

    Parameters p(argc, argv);
    long long i, N;
    p.Get("n", N);

    Timer T;
    T.start();
     
    d = 1.0/N;
    d2 = d*d;

    begin = MPI_Wtime();
    N1 = 0; // calculer
    N2 = 0; // calculer

    for (i=N1; i<N2; i++)
    {
      x2=d2*i*i;
      sum += 1.0/(1.0+x2);
    }
    
    end = MPI_Wtime();
    T.stop();

    if (rank==0)
    {
      pi=4*d*sum;
      printf("Cpu time %9.3f s (%9.3f s)\n %2d MPI process(es)\n\n"
             "PI         =%15.10g\nPI(machine)=%15.10g\nError      =%15.2g\n", 
             T.elapsed(), end-begin, size, pi, 4*atan(1.0), fabs(4*atan(1.0)-pi));
    }

    return 0;
}
