#include <stdio.h>
#include <omp.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "parameters.hxx"
#include "timer.hxx"

int main(int argc, char *argv[])
{
    double pi=0.0, sum=0.0, x2;

    long long i, N;
    Parameters p(argc, argv);
    p.Get("n", N);
    int nThreads;
    p.Get("threads", nThreads);

    if (nThreads == 0)
    {
      char *e = getenv("OMP_NUM_THREADS");
      if (e) {
        char *end;
        nThreads = strtol(e, &end, 10);
        if (*end != '\0')
          nThreads = 1;
      }
      else {
        nThreads = 1;
      }
    }
    omp_set_num_threads(nThreads);

    Timer T;
    T.start();
    double begin = omp_get_wtime();
     
    double d = 1.0/N;
    double d2 = d*d;

    for (i=0; i<N; i++)
    {
      x2=d2*i*i;
      sum += 1.0/(1.0+x2);
    }
    
    double end = omp_get_wtime();
    T.stop();
    
    double pi=4*d*sum;
    printf("Cpu time %9.3f s (%9.3f s)\n%2d OpenMP thread(s)\n\n"
           "PI         =%15.10g\nPI(machine)=%15.10g\nError      =%15.2g\n", 
           T.elapsed(), end-begin, nThreads, pi, 4*atan(1.0), fabs(4*atan(1.0)-pi));
    return 0;
}
