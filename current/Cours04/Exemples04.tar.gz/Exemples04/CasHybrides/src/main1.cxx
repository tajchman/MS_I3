#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <mpi.h>
#include <omp.h>

#define MAX_MESSAGE 1024

int main(int argc, char **argv)
{
  int provided;
  int requested = MPI_THREAD_MULTIPLE;

  MPI_Init_thread(&argc, &argv, requested, &provided);

  if(provided < requested) {
    std::cerr << "  support MPI-OpenMP insuffisant" 
              << "\n\trequested : " << requested
              << "\n\tprovided : " << provided << std::endl;
    MPI_Abort(MPI_COMM_WORLD, -1);
  }
  else
  {
    std::cerr << "support MPI-OpenMP ok\n";
  }

  int rank, size;
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  std::stringstream s;
  s << "out_" << rank << "_on_" << size << ".txt"; 
  std::ofstream f(s.str().c_str());

  f << std::left << std::setw(33) << "________________" << "\n" 
    << std::left << std::setw(33) << "Executable main1" << "\n\n";

  char tampon[MAX_MESSAGE];

  if (rank == 0) {
    f << std::left << std::setw(33) << "Processus 0/2" << "\n\n";
    sprintf(tampon, "A");
    MPI_Send(tampon, MAX_MESSAGE, MPI_CHAR, 1, 0, MPI_COMM_WORLD);

    f << "message envoye '" << tampon << "'                \n"  << std::endl;
  }
  if (rank == 1) {
    f << "Processus 1/2" << "\n\n";

    MPI_Status status;
    MPI_Recv(tampon, MAX_MESSAGE, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &status);

    f << "message recu '" << tampon << "'\n" << std::endl;
  }

  omp_set_num_threads(2);

#pragma omp parallel private(tampon)
  {
    int iThread = omp_get_thread_num();
    if (rank == 0) {
      int tag = iThread;
      sprintf(tampon, "B%d", iThread);
      MPI_Send(tampon, MAX_MESSAGE, MPI_CHAR, 1, tag, MPI_COMM_WORLD);

#pragma omp critical
      f << "dans thread " << iThread 
                << ", message envoye '" << tampon << "'" << std::endl;

    }
    if (rank == 1) {
      int tag = iThread;
      MPI_Status status;
      MPI_Recv(tampon, MAX_MESSAGE, MPI_CHAR, 0, tag, MPI_COMM_WORLD, 
               &status);

#pragma omp critical
      f << "dans thread " << iThread 
        << ", message recu '" << tampon << "'" << std::endl;
    }
  }

  MPI_Finalize();
  return 0;
}
