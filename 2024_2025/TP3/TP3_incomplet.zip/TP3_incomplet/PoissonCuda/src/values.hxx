#ifndef __VALUES__
#define __VALUES__

#include "parameters.hxx"
#include <vector>
#include <iostream>

#define IDX(i,j,k) ((i)*n1*n2 + (j)*n1 + k)

class Values {

public:

  Values(Parameters & p);
  virtual ~Values();
  void operator= (const Values &);
  
  void init();
  void zero();
  void boundaries();

  inline double & operator() (int i,int j,int k) {
    return m_hu[IDX(i,j,k)];
  }
  inline double operator() (int i,int j,int k) const {
    return m_hu[IDX(i,j,k)];
  }
  
  void plot(int order);
  void swap(Values & other);
  size_t size() const { return n_total; }
  int size(int i) const { return m_n[i]; }
  void print(std::ostream &f);

  double * host_data() { return m_hu; }
  const double * host_data() const { return m_hu; }
  double * device_data() { return m_du; }
  const double * device_data() const { return m_du; }

  void synchronized(bool b) { h_synchronized = b; }
  void copyGPUtoCPU();

private:

  Values(const Values &);

  mutable bool h_synchronized;
  double * m_du, * m_hu;

  Parameters & m_p;
  int m_imin[3];
  int m_imax[3];
  int m_n[3];

  double m_dx[3];
  double m_xmin[3];
  double m_xmax[3];

  size_t n_total, n_bytes;
  int n0, n1, n2;
};

std::ostream & operator<< (std::ostream & f, Values & v);

#endif
