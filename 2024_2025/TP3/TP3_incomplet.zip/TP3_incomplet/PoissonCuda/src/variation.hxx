#include "values.hxx"

double variation
 (const Values & u, const Values & v, 
  Values & diff);
