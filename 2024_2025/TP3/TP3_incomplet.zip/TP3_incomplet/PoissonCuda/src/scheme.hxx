/*
 * scheme.hxx
 *
 *  Created on: 5 janv. 2016
 *      Author: tajchman
 */

#ifndef SCHEME_HXX_
#define SCHEME_HXX_

#include <vector>
#include "values.hxx"
#include "parameters.hxx"

class Scheme {

public:
  Scheme(Parameters &P);

  double present();

  void iteration();
  double variation() { return m_duv; }

  Values & getOutput();
  void setInput(const Values & u);

  std::string codeName;

protected:
  int m_n[3];
  double m_t, m_dt;
  double m_dx[3];
  double m_xmin[3];

  Values m_u, m_v, m_diff;
  double m_duv;
  Parameters &m_P;
};

#endif /* SCHEME_HXX_ */
