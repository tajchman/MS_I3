#include "scheme.hxx"
#include "parameters.hxx"
#include "version.hxx"
#include "force.hxx"
#include <cmath>

#include <sstream>
#include <iomanip>

Scheme::Scheme(Parameters &P) :
    codeName(version), m_P(P), m_u(P), m_v(P)  {

  m_t = 0.0;
  m_duv = 0.0;

  int i;
  for (i = 0; i < 3; i++)
  {
    m_n[i] = m_P.n(i);
    m_dx[i] = m_P.dx(i);
    m_xmin[i] = m_P.xmin(i);
  }

  m_dt = m_P.dt();
}

Scheme::~Scheme()
{
}

double Scheme::present()
{
  return m_t;
}

void Scheme::iteration()
{
  double lam_x = 1 / (m_dx[0] * m_dx[0]);
  double lam_y = 1 / (m_dx[1] * m_dx[1]);
  double lam_z = 1 / (m_dx[2] * m_dx[2]);
  double xmin = m_xmin[0];
  double ymin = m_xmin[1];
  double zmin = m_xmin[2];
  double dx = m_dx[0];
  double dy = m_dx[1];
  double dz = m_dx[2];
  int i, j, k;
  double du, du1, du2, du_sum = 0.0;
  
  double x, y, z;

  for (i = imin; i <= imax; i++)
    for (j = jmin; j <= jmax; j++)
      for (k = kmin; k <= kmax; k++) {

        du1 = (-2 * m_u(i, j, k) + m_u(i + 1, j, k) + m_u(i - 1, j, k)) * lam_x
            + (-2 * m_u(i, j, k) + m_u(i, j + 1, k) + m_u(i, j - 1, k)) * lam_y
            + (-2 * m_u(i, j, k) + m_u(i, j, k + 1) + m_u(i, j, k - 1)) * lam_z;

        x = xmin + i * dx;
        y = ymin + j * dy;
        z = zmin + k * dz;
        du2 = force(x, y, z, m_t);

        du = m_dt * (du1 + du2);
        m_v(i, j, k) = m_u(i, j, k) + du;

        du_sum += du > 0 ? du : -du;
      }

  return du_sum;
}

const Values & Scheme::getOutput()
{
  return m_u;
}

void Scheme::setInput(const Values & u)
{
  m_u = u;
  m_v = u;
}

