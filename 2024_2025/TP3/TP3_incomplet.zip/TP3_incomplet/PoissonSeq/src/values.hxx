#ifndef __VALUES__
#define __VALUES__

#include "parameters.hxx"
#include <vector>
#include <iostream>

#define IDX(i,j,k) ((i)*n1*n2 + (j)*n1 + k)

class Values {

public:

  Values(Parameters & p);
  virtual ~Values();
  void operator= (const Values &);
  
  void init();
  void zero();
  void boundaries();

  inline double & operator() (int i,int j,int k) {
    return m_u[IDX(i,j,k)];
  }
  inline double operator() (int i,int j,int k) const {
    return m_u[IDX(i,j,k)];
  }

  void plot(int order) const;
  void swap(Values & other);
  int size(int i) const { return m_n[i]; }
  void print(std::ostream &f) const;
  
private:

  Values(const Values &);
  double * m_u;
  Parameters & m_p;
  int m_imin[3];
  int m_imax[3];
  int m_n[3];

  double m_dx[3];
  double m_xmin[3];
  double m_xmax[3];

  size_t n_total, n_bytes;
  int n0, n1, n2;
};

std::ostream & operator<< (std::ostream & f, const Values & v);

#endif
