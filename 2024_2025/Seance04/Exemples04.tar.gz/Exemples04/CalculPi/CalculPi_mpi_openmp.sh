#! /bin/bash

#SBATCH --job-name=CalculPi
#SBATCH --output=output_mpi_openmp.txt
#SBATCH --error=output_mpi_openmp.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=2
#SBATCH --cpus-per-task=2
#SBATCH --time=00:01:00
#SBATCH --hint=nomultithread

## load modules

module purge >& /dev/null
module load gcc/10.2.0 >& /dev/null
module load openmpi/4.1.4 >& /dev/null

## execution
if [ -z $SLURM_CPUS_PER_TASK ] ; then export SLURM_CPUS_PER_TASK=2 ; fi
if [ -z $SLURM_NTASKS ] ; then export SLURM_NTASKS=2 ; fi

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export OMPI_MCA_mca_base_component_show_load_errors=0
mpirun -n $SLURM_NTASKS --bind-to none ./install/mpi_openmp_pi

