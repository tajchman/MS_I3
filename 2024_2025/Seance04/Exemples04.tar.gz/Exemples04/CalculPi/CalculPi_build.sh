#! /bin/bash

#SBATCH --job-name=CalculPi
#SBATCH --output=log_build.txt
#SBATCH --error=log_build.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=00:02:00

## load modules

module purge >& /dev/null
module load gcc/10.2.0 >& /dev/null
module load openmpi/4.1.4 >& /dev/null

rm -rf install
mkdir -p install

gcc -I src/tools -I src src/pi.c -o install/pi

gcc -fopenmp -I src/tools -I src src/openmp_pi.c -o install/openmp_pi

mpicc -I src/tools -I src src/mpi_pi.c -o install/mpi_pi

mpicc -fopenmp -I src/tools -I src src/mpi_openmp_pi.c -o install/mpi_openmp_pi

