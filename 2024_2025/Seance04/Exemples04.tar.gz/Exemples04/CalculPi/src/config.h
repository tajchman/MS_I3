long long defaultN = 10000000000L;

