#include <stdio.h>
#include <omp.h>
#include <stdlib.h>
#include <math.h>
#include "config.h"

int main(int argc, char *argv[])
{
    int it = 0, nt = omp_get_max_threads();
    double pi=0.0, sum=0.0, begin=0.0, end=0.0, x2;
    double d, d2;

    long long i, N = argc > 1 ? atoll(argv[1]) : defaultN;
    d = 1.0/N;
    d2 = d*d;

    begin = omp_get_wtime();

    #pragma omp parallel for private(x2) reduction(+:sum)
    for (i=0; i<N; i++)
    {
        x2=d2*i*i;
        sum+=1.0/(1.0+x2);
    }
    
    end = omp_get_wtime();

    pi=4*d*sum;
    printf("Cpu time %9.3f s %2d OpenMP thread(s)\n\n"
           "PI         =%15.10g\nPI(machine)=%15.10g\nError      =%15.2g\n", 
           end-begin, nt, pi, 4*atan(1.0), fabs(4*atan(1.0)-pi));
    
    return 0;
}
