#! /bin/bash

#SBATCH --job-name=CalculPi
#SBATCH --output=output_mpi.txt
#SBATCH --error=output_mpi.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --tasks=4
#SBATCH --time=00:01:00

## load modules

module purge >& /dev/null
module load gcc/10.2.0 >& /dev/null
module load openmpi/4.1.4 >& /dev/null

## execution
if [ -z $SLURM_NTASKS ] ; then export SLURM_NTASKS=4 ; fi
export OMPI_MCA_mca_base_component_show_load_errors=0
mpirun -n $SLURM_NTASKS ./install/mpi_pi


