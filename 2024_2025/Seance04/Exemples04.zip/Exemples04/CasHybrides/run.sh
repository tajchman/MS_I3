#!/bin/bash

#SBATCH --job-name=Hybrid
#SBATCH --output=output.txt
#SBATCH --error=output.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=2
#SBATCH --cpus-per-task=2
#SBATCH --time=00:05:00

## load modules

module load cmake/3.29.3 >& /dev/null
module load gcc/10.2.0 >& /dev/null
module load openmpi/4.1.4 >& /dev/null

## compilation

cmake -S src -B build -DCMAKE_INSTALL_PREFIX=install
make -C build install

## execution

export OMPI_MCA_mca_base_component_show_load_errors=0
export OMP_NUM_THREADS=2
mpirun -n 2 ./install/main1
mpirun -n 2 ./install/main2
mpirun -n 2 ./install/main3
