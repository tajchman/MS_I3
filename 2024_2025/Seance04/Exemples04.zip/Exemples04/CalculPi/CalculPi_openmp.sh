#! /bin/bash

#SBATCH --job-name=CalculPi
#SBATCH --output=output_openmp.txt
#SBATCH --error=output_openmp.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --time=00:01:00

## load modules

module purge >& /dev/null

module load gcc/10.2.0 >& /dev/null

## execution

if [ -z $SLURM_CPUS_PER_TASK ] ; then export SLURM_CPUS_PER_TASK=4 ; fi
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
./install/openmp_pi

