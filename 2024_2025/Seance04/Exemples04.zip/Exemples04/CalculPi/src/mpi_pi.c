#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <math.h>
#include "config.h"

int main(int argc, char *argv[])
{
    int size, rank, namelen;
    char processor_name[MPI_MAX_PROCESSOR_NAME];
    double pi=0.0, result=0.0, sum=0.0, begin=0.0, end=0.0, x2;
    double d, d2;

    long long i, N = argc > 1 ? atoll(argv[1]) : defaultN;
    d = 1.0/N;
    d2 = d*d;

    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Barrier(MPI_COMM_WORLD);
    if (rank == 0) {
      begin = MPI_Wtime();
    }

    for (i=rank; i<N; i+=size)
    {
        x2=d2*i*i;
        result+=1.0/(1.0+x2);
    }
    
    MPI_Reduce(&result, &sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    
    
    if (rank==0)
    {
        end = MPI_Wtime();
        pi=4*d*sum;
        printf("Cpu time %9.3f s %2d MPI process(es)\n\n"
               "PI         =%15.10g\nPI(machine)=%15.10g\nError      =%15.2g\n", 
               end-begin, size, pi, 4*atan(1.0), fabs(4*atan(1.0)-pi));
    }
    
    MPI_Finalize();

    return 0;
}
