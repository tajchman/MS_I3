#! /bin/bash

#SBATCH --job-name=CalculPi
#SBATCH --output=output_seq.txt
#SBATCH --error=output_seq.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=00:01:00

## load modules

module purge >& /dev/null

module load gcc/10.2.0 >& /dev/null

## execution

./install/pi

