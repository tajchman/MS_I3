#ifndef __MATRICE_H
#define __MATRICE_H

#include <iostream>

class Matrice {

public:
    virtual ~Matrice() {}
    float * data() { return _c; }
    const float * data() const { return _c; }
    int n() const { return _n;}
    int m() const { return _m;}
    size_t bytes() { return _nbytes; }
    virtual void allocate(int n, int m) = 0;
    
protected:
    Matrice() : 
            _n(0), _m(0), 
            _c(nullptr), 
            _nbytes(0) {}
    float *_c;
    int _n, _m;
    size_t _nbytes;
};

class hMatrice : public Matrice
{
public:
    hMatrice() {}
    ~hMatrice();
    void allocate(int n, int m);
    float & operator()(int i, int j) 
       { return _c[j + i*_m]; }
    float operator()(int i, int j) const 
       { return _c[j + i*_m]; }
};

class dMatrice : public Matrice
{
public:
    dMatrice() {}
    ~dMatrice();
    void allocate(int n, int m);
};

std::ostream & operator<< (std::ostream & f, const hMatrice & M);

#endif
