#! /usr/bin/env python3
# -*- coding: utf-8 -*-

try:
    unicode('')
except NameError:
    unicode = str

import os, sys, argparse
from subprocess import *

try:
  import matplotlib
  import matplotlib.pyplot as plt
  graphics = True
except:
  graphics = False

def read(filename):
    with open(os.path.join(filename)) as f:
        i = []
        t = []
        for line in f:
            if len(line) < 1 or line[0] == "#":
               continue
            l = line.split()
            if len(l) != 2:
                break;
            i.append(int(l[0]))
            t.append(float(l[1]))
    return (i, t)

display = False

def plot(s, ax):
  ax.set_xlabel(s.capitalize())
  for t in ["double", "float"]:
    i, v = read("res_" + t + "_" + s + ".txt")
    ax.plot(i, v, 'o-', label=t)
  ax.legend()
  ax.grid()

if graphics:
  fig, ax = plt.subplots(2, 1, figsize=(10,10))

  plot('stride', ax[0])
  plot('offset', ax[1])

  plt.savefig("Offset_stride.pdf")

  if display:
    plt.show()
  else:
    plt.ioff()

