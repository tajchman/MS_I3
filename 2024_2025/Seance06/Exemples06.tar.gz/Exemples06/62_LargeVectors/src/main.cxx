
#include <cstdlib>
#include <iostream>
#include <iomanip>

#include "calcul_Cuda.hxx"
#include "timer.hxx"

int main(int argc, char **argv)
{ 
  test();

  std::cerr << "Version : Cuda (reduction sur CPU)" << std::endl;
  AddTimer("total");

  Properties p;
  GetProperties(p);

  p.N = argc > 1 ? strtoll(argv[1], NULL, 10) : p.Nmax;
  if (p.N <= 0)
    p.N = p.Nmax;

  p.BlockDim = 1;
  Calcul_Cuda C(p);
  std::cout << std::endl;

  while (p.BlockDim <= p.BlockMax)
  {
    double v;
  
    Timer T_init;
    T_init.start();
    C.init();
    T_init.stop();

    Timer T_add;
    T_add.start();
    C.addition();
    T_add.stop();

    v = C.verification();
    std::cout << " bloc size " << std::setw(6) << p.BlockDim 
              << " nb blocs " << std::setw(12) << p.nBlocks 
              << " temps init : " << std::setw(6) << T_init.elapsed() << " s" 
              << " temps addition : " << std::setw(6) << T_add.elapsed() << " s"
              << " erreur " << v << std::endl;

    p.BlockDim *= 2;
  }
  std::cout << std::endl << "fin" << std::endl;

  return 0;
}
