#pragma once

#include "Matrice.hxx"

void alloc_CPU(hMatrice & u, hMatrice & v, hMatrice & w, hMatrice & h_verif, int n, int m, int p);
void alloc_GPU(dMatrice &d_u, dMatrice &d_v, dMatrice &d_w, int n, int m, int p);

void init_CPU(hMatrice &h_u, hMatrice &h_v);

void matMul_CPU(hMatrice &c, hMatrice &a, hMatrice &b);
void matMul_GPU(dMatrice &c, dMatrice &a, dMatrice &b);
void matMul_GPU_Cublas(dMatrice &d_w, dMatrice &d_u, dMatrice &d_v);

void copy_CPU_GPU(dMatrice &d_u, dMatrice &d_v, hMatrice &h_u, hMatrice &h_v);
void copy_GPU_CPU(hMatrice &h_w, dMatrice &d_w);

double verification(hMatrice &h_w, hMatrice &h_verif);

