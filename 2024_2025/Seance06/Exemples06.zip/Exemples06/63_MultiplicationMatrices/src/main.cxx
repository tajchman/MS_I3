
#include <iostream>
#include <fstream>
#include <iomanip>
#include "Matrice.hxx"
#include "produit_matrices.hxx"

#ifndef n_print
#define n_print 10
#endif

int main(int argc, char **argv)
{
  int n = argc > 1 ? atol(argv[1]) : 2000;
  int m = n, p = n;
  double r;

  std::cout << std::endl;

  hMatrice h_u, h_v, h_w, h_verif;
  alloc_CPU(h_u, h_v, h_w, h_verif, n, n, n);
  init_CPU (h_u, h_v);

  if (n < n_print) {
    std::ofstream f("UV");
    f << "U" << h_u << std::endl;
    f << "V" << h_v << std::endl;
  }

  matMul_CPU(h_verif, h_u, h_v);

  if (n < n_print) {
    std::ofstream f("rCPU");
    f << h_verif << std::endl;
  }

  dMatrice d_u, d_v, d_w;
  alloc_GPU(d_u, d_v, d_w, n, n, n);

  copy_CPU_GPU(d_u, d_v, h_u, h_v);

  matMul_GPU(d_w, d_u, d_v);
  copy_GPU_CPU(h_w, d_w);
  r = verification(h_w, h_verif);
  std::cout << "\tDifférence CPU-GPU : " << std::scientific << r << "\n\n";
  if (n < n_print) {
    std::ofstream f("rGPU");
    f << h_w << std::endl;
  }

  
  matMul_GPU_Cublas(d_w, d_u, d_v);
  copy_GPU_CPU(h_w, d_w);
  r = verification(h_w, h_verif);
  std::cout << "\tDifférence CPU-GPU (cublas) : " << std::scientific << r << "\n\n";
  if (n < n_print) {
    std::ofstream f("rGPU_cublas");
    f << h_w << std::endl;
  }

  return 0;
}