#!/bin/bash

#SBATCH --job-name=DeviceQuery
#SBATCH --output=output.txt
#SBATCH --error=output.txt

#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --account=ams301

#SBATCH --ntasks=1
#SBATCH --time=00:02:00

## load modules

host=`hostname`
echo $host
if [[ "x$host" == xcholesky* ]]
then
  module purge
  module load gcc/13.2.0
  module load cuda/12.4
  module load cmake
fi

## compilation

cmake -S src -B build -DCMAKE_INSTALL_PREFIX=install
make -C build install

## execution

./install/exemple_thrust4 100
./install/exemple_thrust4 1000
./install/exemple_thrust4 10000
./install/exemple_thrust4 100000
./install/exemple_thrust4 1000000
./install/exemple_thrust4 10000000
./install/exemple_thrust4 100000000

