#!/bin/bash

#SBATCH --job-name=coalescence
#SBATCH --output=output.txt
#SBATCH --error=output.txt
#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --account=ams301

#SBATCH --time=00:05:00
#SBATCH --ntasks=1

## load modules

host=`hostname`

if [[ "x$host" == xnode* || "x$host" == xcholesky* ]]
then
  module purge
  module load cuda/12.4
  module load gcc/13.2.0
  module load cmake
  module load anaconda
fi

## compilation

python3 build.py
echo

## execution

./install/coalescence
echo

python3 plot.py