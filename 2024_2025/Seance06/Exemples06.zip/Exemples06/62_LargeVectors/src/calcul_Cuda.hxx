#ifndef _CALCUL_HXX
#define _CALCUL_HXX

struct Properties
{
  size_t Nmax;
  unsigned int BlockMax;

  size_t N;
  unsigned int BlockDim;

  size_t nBlocks;
};

class Calcul_Cuda {
public:
  Calcul_Cuda(Properties & p);
  ~Calcul_Cuda();

  void init();
  void addition();
  double verification();

private:
  Properties & _p;
  size_t n;
  double *d_u, *d_v, *d_w;
  unsigned int blockSize, gridSize;
};

void GetProperties(Properties &p);
void test();

#endif

