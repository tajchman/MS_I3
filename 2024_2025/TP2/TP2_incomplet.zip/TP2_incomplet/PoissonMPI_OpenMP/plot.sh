#! /bin/bash

module load anaconda3/2023.09
python3 plot.py
