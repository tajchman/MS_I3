#! /usr/bin/env python
# -*- coding: utf-8 -*-

try:
    unicode('')
except NameError:
    unicode = str

import os, sys, subprocess
from util import *

def manage(np, nt):
    job = '''#!/bin/bash

#SBATCH --job-name=@VERSION@
#SBATCH --output=output_@NP@_@NT@.txt
#SBATCH --error=output_@NP@_@NT@.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=@NP@
#SBATCH --cpus-per-task=@NT@
#SBATCH --time=@RUNTIME@

## load modules

module purge
module load cmake
module load gcc/13.2.0
module load openmpi/4.1.6

## execution
export OMPI_MCA_mca_base_component_show_load_errors=0
python3 -u ./build.py
python3 -u ./run.py --np @NP@ --threads @NT@
mv log_PoissonMPI_OpenMP.txt log_PoissonMPI_OpenMP_@NP@_@NT@.txt
'''

    baseDir = os.getcwd()
    installDir = os.path.join(baseDir, 'install')
    version = os.path.basename(baseDir)
    args = standardArgs(baseDir, False, version)

    s = job
    s = s.replace("@VERSION@", version)
    s = s.replace("@ACC@", queue())
    s = s.replace("@NP@", str(np))
    s = s.replace("@NT@", str(nt))
    s = s.replace("@RUNTIME@", args['runtime'])

    jobFile = 'run.sh'
    with open(jobFile, 'w') as f:
       f.write(s)

    subprocess.call(['sbatch', jobFile])

if __name__ == '__main__':
    manage(1,1)
    manage(8,1)
    manage(4,2)
    manage(2,4)
    manage(1,8)
