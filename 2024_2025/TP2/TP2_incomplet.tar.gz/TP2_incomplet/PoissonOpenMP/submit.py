#! /usr/bin/env python
# -*- coding: utf-8 -*-

try:
    unicode('')
except NameError:
    unicode = str

import os, sys, subprocess
from util import *

def manage():
    job = '''#!/bin/bash

#SBATCH --job-name=@VERSION@
#SBATCH --output=output.txt
#SBATCH --error=output.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=@NP_MAX@
#SBATCH --cpus-per-task=@THREADS_MAX@
#SBATCH --time=@RUNTIME@

## load modules

module purge
module load cmake
module load gcc/13.2.0
module load openmpi/4.1.6

## execution
python3 -u ./build.py
python3 -u ./run.py
python3 -u ./plot.py

'''

    baseDir = os.getcwd()
    installDir = os.path.join(baseDir, 'install')
    version = os.path.basename(baseDir)
    args = standardArgs(baseDir, False, version)

    s = job
    s = s.replace("@VERSION@", version)
    s = s.replace("@ACC@", queue())
    s = s.replace("@NP_MAX@", '1')
    s = s.replace("@THREADS_MAX@", str(args['threadsMax']))
    s = s.replace("@RUNTIME@", args['runtime'])

    jobFile = 'run.sh'
    with open(jobFile, 'w') as f:
       f.write(s)

    if os.path.exists('output.txt'):
       os.unlink('output.txt')
 
    subprocess.call(['sbatch', jobFile])

if __name__ == '__main__':
    manage()
