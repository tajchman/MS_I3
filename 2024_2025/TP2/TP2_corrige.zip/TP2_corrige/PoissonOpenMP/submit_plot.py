#! /usr/bin/env python
# -*- coding: utf-8 -*-

import subprocess


subprocess.call(['/mnt/beegfs/softs/intel/intelpython3/bin/python', 'plot.py'])
