#include <iostream>
#include <iomanip>
#include <cassert>

#include "hMatrix.hxx"
#include "hVector.hxx"

#include "arguments.hxx"
#include "timer.hxx"
#include "hData.hxx"

#include "version.hxx"

void init(hMatrix &M, double a)
{
  size_t n = M.n(), m = M.m(), nm = n*m;
  double *c = M.data();
  double x = a/(nm-1);
  size_t i;

  for (i=0; i<nm; i++)
    c[i] = x * i;
}

void init(hVector &v, double a)
{
  size_t n = v.n();
  double *c = v.data();
  double x = a/(n-1);
  size_t i;

  for (i=0; i<n; i++)
    c[i] = x * i;
}

void matvec(hVector &w,
            const hMatrix &A,
            const hVector &v)
{
  assert(A.n() == w.n());
  assert(A.m() == v.n());

  size_t i, j, n = A.n(), m = A.m() ;
  const double *x = v.data();
  double * y = w.data();
  const double *M = A.data();
  double s;

  for (i=0;i<n; i++) {
    s = 0.0;
    for (j=0; j<m; j++)
      s += M[i*m + j] * x[j];
    y[i] = s;
  }
}

double dot(const hVector &w, const hVector &v)
{
  int i, n = v.n();
  const double *x = v.data();
  const double *y = w.data();
  double result = 0.0;
  for (i=0; i<n; i++)
    result += x[i] * y[i];

  return result;
}

int main(int argc, char** argv)
{
  Arguments Args(argc, argv);
  size_t n = Args.Get("n", 10000L);
  size_t m = Args.Get("m", n);

  std::cout << "version " << version << "\n\nn,m = " << n << " " << m << "\n\n";

  Timer T_global;
  T_global.start();

  hData D(n, m);

  Timer T_calcul;
  T_calcul.start();

  double s = 0.0;
  
  init(D.y, 1.5);

  init(D.A1, 2.0);
  init(D.x1, 1.0);
  matvec(D.temp1, D.A1, D.x1);
  s += dot(D.y, D.temp1);

  init(D.A2, 3.0);
  init(D.x2, 1.2);
  matvec(D.temp2, D.A2, D.x2);
  s += dot(D.y, D.temp2);

  T_calcul.stop();

  std::cout << "\n\ty(A1 x1 + A2 x2) = " << s << std::endl;

  if (n <= 10 && m <= 10) {
    D.x1.print();
    D.A1.print();
    D.x2.print();
    D.A2.print();
    D.y.print();
  }
  std::cout << "\n";
  T_global.stop();
  std::cout << "T calcul (" << version << ") : " << T_calcul.elapsed() << " s" << std::endl;
  std::cout << "T global (" << version << ") : " << T_global.elapsed() << " s" << std::endl;
  return 0;
}
