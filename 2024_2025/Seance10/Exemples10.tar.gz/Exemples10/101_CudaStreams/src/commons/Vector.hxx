#pragma once

#include <cstddef>
#include <string>

class Vector
{
public:
  Vector(size_t p, const char *name) 
    : _n(p), 
      _bytes(_n*sizeof(double)), 
      _name(name)  {}
  ~Vector() {}

  size_t n() const { return _n; }
  double * data() { return _data; }
  const double * data() const { return _data; }
  const std::string & name() const { return _name; }

  virtual void print() const = 0;

protected:
  double * _data;
  size_t _n;
  size_t _bytes;
  std::string _name;
};
