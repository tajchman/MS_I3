#pragma once

#include "Vector.hxx"

class dVector : public Vector
{
public:
  
  dVector(size_t p, const char *name = "");
  ~dVector();

  void print() const;

protected:
};
