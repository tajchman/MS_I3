#pragma once

#include "dVector.hxx"
#include "dMatrix.hxx"

struct dData {
  dData(size_t n, size_t m) 
    : A1   (n, m, "A1"), 
      A2   (n, m, "A2"), 
      x1   (m, "x1"),
      x2   (m, "x2"),
      y    (n, "y"), 
      temp1(n, "temp1"),
      temp2(n, "temp2")
    { }

  dMatrix A1, A2;
  dVector x1, x2, y, temp1, temp2;
};
