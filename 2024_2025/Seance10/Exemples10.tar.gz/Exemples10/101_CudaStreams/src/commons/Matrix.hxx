#pragma once

#include <cstddef>
#include <iostream>
#include <iomanip>
#include <string>

class Matrix
{
public:
  Matrix(size_t p, size_t q, const char *name) 
     : _n(p), _m(q), _bytes(_n*_m*sizeof(double)), _name(name) {}
  virtual ~Matrix() {}

  size_t n() const { return _n; }
  size_t m() const { return _m; }
  double * data() { return _data; }
  const double * data() const { return _data; }
  const std::string & name() const { return _name; }

  virtual void print() const = 0;

protected:
  size_t _n, _m;
  size_t _bytes;
  double * _data;
  std::string _name;
};

