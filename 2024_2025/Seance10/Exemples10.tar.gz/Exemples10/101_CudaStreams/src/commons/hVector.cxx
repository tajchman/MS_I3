#include "hVector.hxx"

hVector::hVector(size_t n, const char *name) : Vector(n, name)
{
  _data = new double[_n];
}

hVector::~hVector()
{
  if (_data)
    delete [] _data;
}

void hVector::print() const
{
  if (_data == nullptr) return;

  size_t i, j;

  printf("%s\n", _name.c_str());
  for (i=0; i<_n; i++) {
    printf("%5zu : %12.5g\n", i, _data[i]);
  }
  printf("\n");
}
