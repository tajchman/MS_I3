
#ifndef __DOTCUDA_H__
#define __DOTCUDA_H__

#include <cstddef>

double dotCuda(unsigned long n,
               const double *d_idata1, const double *d_idata2,
               size_t threads,
               size_t blocks,
               cudaStream_t stream);

#endif
