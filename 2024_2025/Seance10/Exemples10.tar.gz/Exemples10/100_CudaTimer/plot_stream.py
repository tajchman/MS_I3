#! /usr/bin/env python3

import sys, os, subprocess, argparse

parser = argparse.ArgumentParser()
parser.add_argument('-n', '--n', type=int, default=5000000)
args = parser.parse_args()

with open("res_stream", "w") as f:
  subprocess.run(['./build/gputimer_stream', '--n', str(args.n)], stdout=f)

ops = {}
xmax = -1
qmax = -1
with open("res_stream") as f:
  for l in f:
    ll = l.split()
    if len(ll) <10:
      continue
    op = {}
    op['queue'] = int(ll[1])
    op['execTime'] = float(ll[3])
    op['startTime'] = float(ll[6])
    op['endTime'] = float(ll[9])
    ops[ll[2][:-1]] = op

    if xmax < float(ll[9]):
      xmax = float(ll[9])
    if qmax < int(ll[1]):
      qmax = int(ll[1])

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import matplotlib.colors as mcolors
from matplotlib.backends.backend_pdf import PdfPages

fig, ax = plt.subplots(figsize=(8, 2))
ax.set_xlim(0, xmax)
ax.set_ylim(0, 2+qmax)

colors = list(mcolors.BASE_COLORS)
ic = 0

for it in ops:
  if it.startswith("CudaMalloc"):
    c = colors[0]
  elif it.startswith("CudaFree"):
    c = colors[1]
  elif it.startswith("Init"):
    c = colors[2]
  else:
    c = colors[3]
    
  op = ops[it]
  ax.add_patch(Rectangle((op['startTime'], 0.6 + op['queue']), op['execTime'], 0.4, facecolor=c, edgecolor='black'))
  ic = ic+1
  
ax.add_patch(Rectangle((0.1, 0.05), 0.07, 0.04, facecolor=colors[0], edgecolor='black', transform=ax.transAxes))
plt.text(0.2, 0.05, "CudaMalloc", color='k', fontsize=12, transform=ax.transAxes)
ax.add_patch(Rectangle((0.1, 0.15), 0.07, 0.04, facecolor=colors[1], edgecolor='black', transform=ax.transAxes))
plt.text(0.2, 0.15, "CudaFree", color='k', fontsize=12, transform=ax.transAxes)
ax.add_patch(Rectangle((0.4, 0.05), 0.07, 0.04, facecolor=colors[2], edgecolor='black', transform=ax.transAxes))
plt.text(0.5, 0.05, "Init", color='k', fontsize=12, transform=ax.transAxes)
ax.add_patch(Rectangle((0.4, 0.15), 0.07, 0.04, facecolor=colors[3], edgecolor='black', transform=ax.transAxes))
plt.text(0.5, 0.15, "Calcul", color='k', fontsize=12, transform=ax.transAxes)

with PdfPages('res_stream.pdf') as pdf:
  pdf.savefig(fig)
plt.show()
