#pragma once

#include "Vector.hxx"

class hVector : public Vector
{
public:
  
  hVector(size_t p, const char *name = "");
  ~hVector();

  void print() const ;

protected:
};

