#include "hMatrix.hxx"

hMatrix::hMatrix(size_t n, size_t m, const char *name) : Matrix(n, m, name)
{
  _data = new double[_n*_m];
}

hMatrix::~hMatrix()
{
  if (_data)
    delete [] _data;
}

void hMatrix::print() const
{
  if (_data == nullptr) return;

  size_t i, j;

  printf("%s\n", _name.c_str());
  for (i=0; i<_n; i++) {
    printf("%5zu :", i);
    for (j=0; j<_m; j++)
      printf(" %12.5g", _data[i*_m + j]);
    printf("\n");
  }
}
