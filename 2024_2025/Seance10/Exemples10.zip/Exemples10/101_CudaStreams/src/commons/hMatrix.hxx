#pragma once

#include "Matrix.hxx"

class hMatrix : public Matrix
{
public:
  
  hMatrix(size_t p, size_t q, const char *name = "");
  ~hMatrix();

  void print() const ;

protected:
};

