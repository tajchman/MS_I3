#pragma once

#include "Matrix.hxx"

class dMatrix : public Matrix
{
public:
  
  dMatrix(size_t p, size_t q, const char *name = nullptr);
  ~dMatrix();

  void print() const;

protected:
};
