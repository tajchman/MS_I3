#pragma once

#include "hVector.hxx"
#include "hMatrix.hxx"
struct hData {
  hData(size_t n, size_t m) 
    : A1   (n, m, "A1"), 
      A2   (n, m, "A2"), 
      x1   (m, "x1"),
      x2   (m, "x2"),
      y    (n, "y"), 
      temp1(n, "temp1"),
      temp2(n, "temp2")
    {}

  hMatrix A1, A2;
  hVector x1, x2, y, temp1, temp2;
};
