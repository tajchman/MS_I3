#!/bin/bash

#SBATCH --job-name=PMV
#SBATCH --output=output.txt
#SBATCH --error=output.txt

#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --account=ams301

#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --exclusive

#SBATCH --time=00:05:00

## load modules

host=`hostname`
echo $host
if [[ "x$host" == xcholesky* ]]
then
  module purge
  module load gcc/13.2.0
  module load cuda/12.4
  module load cmake
fi

## compilation

python3 -u build.py
echo $?
## execution

N=15000
echo
for v in cuda_stream
#serial openmp cuda 
#kokkos_serial kokkos_openmp kokkos_cuda
do
  if [[ "x$v" == x*openmp ]]
  then
    OMP_PROC_BIND=close OMP_PLACES=threads ./install/ex101_$v --n $N --threads 8 | tee res_$v
  else
    ./install/ex101_$v --n $N | tee res_$v
  fi 
done

# post-traitement

#python3 plot.py
