#include <sycl/sycl.hpp>
#include <vector>
#include <algorithm>
#include <iostream>

int main() {
  
  size_t n = 1000000;

  sycl::queue q(sycl::default_selector_v);
  std::cout << "\nRunning on " 
            << q.get_device().get_info<sycl::info::device::name>() 
            << std::endl << std::endl;

  sycl::buffer<float, 1> buffer1(n);
  sycl::buffer<float, 1> buffer2(n);
  sycl::buffer<float, 1> buffer3(n);

  q.submit([&](sycl::handler& h) {

    auto d_v = buffer1.get_access<sycl::access::mode::write>(h);

    h.parallel_for<class Init1>(sycl::range<1>(n), [=](sycl::id<1> i) {
      d_v[i] = float(i) + 1.0;
    });
  });


  q.submit([&](sycl::handler& h) {
    auto d_v = buffer2.get_access<sycl::access::mode::write>(h);

    h.parallel_for<class Init2>(sycl::range<1>(n), [=](sycl::id<1> i) {
      d_v[i] = float(i) * 2.0;
    });
  });

  q.submit([&](sycl::handler& h) {
    auto d_v1 = buffer1.get_access<sycl::access::mode::read>(h);
    auto d_v2 = buffer2.get_access<sycl::access::mode::read>(h);
    auto d_v3 = buffer3.get_access<sycl::access::mode::write>(h);

    h.parallel_for<class Add>(sycl::range<1>(n), [=](sycl::id<1> i) {
      d_v3[i] = d_v1[i] + d_v2[i];
    });
  });
  q.wait();
  sycl::host_accessor v1(buffer1, sycl::read_only);
  sycl::host_accessor v2(buffer2, sycl::read_only);
  sycl::host_accessor v3(buffer3, sycl::read_only);

  std::cout << "v1[" << n/2 << "] = " << v1[n/2] << std::endl;
  std::cout << "v2[" << n/2 << "] = " << v2[n/2] << std::endl;
  std::cout << "v3[" << n/2 << "] = " << v3[n/2] << std::endl;

  return 0;
}
