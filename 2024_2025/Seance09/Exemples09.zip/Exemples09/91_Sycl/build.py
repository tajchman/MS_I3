#! /usr/bin/env python3

import os, subprocess, argparse, platform, sys
e = os.environ.copy()
e['CXX'] = 'icpx'
e['CC'] = 'icx'

baseDir    = os.getcwd()
srcDir     = os.path.join(baseDir, 'src')
buildDir   = os.path.join(baseDir, 'build')
installDir = os.path.join(baseDir, 'install')
  
configureCmd = ['cmake', '-S', srcDir, '-B', buildDir]
configureCmd.append('-DCMAKE_INSTALL_PREFIX=' + installDir)
configureCmd.append('-DCMAKE_INSTALL_MESSAGE=LAZY')
      
compileCmd = ['make', '-C', buildDir, '-j', '4', '--no-print-directory', 'install']

print('\n\t'.join(configureCmd), file=sys.stderr)
print('\n\t' + ' '.join(compileCmd), file=sys.stderr)


subprocess.call(configureCmd, env=e)
subprocess.call(compileCmd, env=e)

print("end compilation ex91", file=sys.stderr)