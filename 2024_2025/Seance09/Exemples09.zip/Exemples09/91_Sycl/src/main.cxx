#include <sycl/sycl.hpp>

int main(int argc, char **argv)
{
  size_t N = 1000000L;
  sycl::queue Q;
  std::cout << "\nRunning on " 
            << Q.get_device().get_info<sycl::info::device::name>()
            << std::endl << std::endl;

  float *d_v1 = sycl::malloc_device<float>(N, Q);
  float *d_v2 = sycl::malloc_device<float>(N, Q);
  float *d_v3 = sycl::malloc_device<float>(N, Q);

  Q.parallel_for(N, [=](auto id) { d_v1[id] = float(id) + 1.0f; }).wait();
  Q.parallel_for(N, [=](auto id) { d_v2[id] = float(id) * 2.0f; }).wait();
  Q.parallel_for(N, [=](auto id) { d_v3[id] = d_v1[id] + d_v2[id]; }).wait();

  std::vector<float> h_v1(N), h_v2(N), h_v3(N);

  Q.copy(d_v1, h_v1.data(), N).wait();
  Q.copy(d_v2, h_v2.data(), N).wait();
  Q.copy(d_v3, h_v3.data(), N).wait();

  sycl::free(d_v1, Q);
  sycl::free(d_v2, Q);
  sycl::free(d_v3, Q);

  std::cout << "v1[" << N/2 << "] = " << h_v1[N/2] << std::endl;
  std::cout << "v2[" << N/2 << "] = " << h_v2[N/2] << std::endl;
  std::cout << "v3[" << N/2 << "] = " << h_v3[N/2] << std::endl;
}
