#!/bin/bash

#SBATCH --job-name=PoissonKokkos
#SBATCH --output=output.txt
#SBATCH --error=output.txt

#SBATCH --partition=cpu_test
#SBATCH --account=ams301

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --exclusive
#SBATCH --time=00:05:00

## load modules

host=`hostname`
echo $host
if [[ "x$host" == xcholesky* ]]
then
  module purge
  module load intel_compiler/oneapi_2023.2.0
  module load cmake
fi

## compilation

python3 build.py

## execution

./install/92_sycl

