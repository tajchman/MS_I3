void init(double *u, int n, int dn);
