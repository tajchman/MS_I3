
double *init(int n, double v0);
