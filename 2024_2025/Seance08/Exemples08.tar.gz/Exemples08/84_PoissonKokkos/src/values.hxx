#ifndef __VALUES__
#define __VALUES__

#include "parameters.hxx"
#include <vector>
#include <iostream>

#include <Kokkos_Core.hpp>

using DeviceArray = Kokkos::View<double ***>;
using HostArray = DeviceArray::HostMirror;

class Values {

public:

  Values(Parameters & p);
  void operator= (const Values &);
  
  void init();
  void boundaries();

  void plot(int order) const;
  void swap(Values & other);
  int size(int i) const { return m_n[i]; }
  void print(std::ostream &f) const;

  HostArray h;
  DeviceArray d;
  
private:
  
  Values(const Values &);
  Parameters & m_p;
  int m_imin[3];
  int m_imax[3];
  int m_n[3];

  double m_dx[3];
  double m_xmin[3];
  double m_xmax[3];

};


std::ostream & operator<< (std::ostream & f, const Values & v);

#endif
