#!/bin/bash

#SBATCH --job-name=InitKokkos
#SBATCH --output=output.txt
#SBATCH --error=output.txt

#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --account=ams301

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --exclusive
#SBATCH --time=00:05:00

## load modules

host=`hostname`
echo $host
if [[ "x$host" == xcholesky* ]]
then
  module purge
  module load gcc/13.2.0
  module load cuda/12.4
  module load cmake
fi

## compilation

python3 build.py

## execution

for b in serial openmp threads cuda
do
  echo ./install/$b/ex81
  if [[ $b == openmp ]]
  then
    OMP_PROC_BIND=close OMP_PLACES=threads OMP_NUM_THREADS=6 ./install/$b/ex81
  else
    ./install/$b/ex81
  fi 
done


