#! /usr/bin/env python

import os, subprocess, shutil, sys

baseDir = os.getcwd()

srcDir = os.path.join(baseDir, 'kokkos')
if not os.path.exists(srcDir):
  subprocess.call(['git', 'clone', 
                   'https://github.com/kokkos/kokkos.git', 
                   '--branch', '4.5.01'],
                  cwd=baseDir)

for backend in ['serial', 'openmp', 'cuda']:
  buildDir = os.path.join(baseDir, 'build', 'kokkos_' + backend)
  installDir = os.path.join(baseDir, 'install', 'kokkos_' + backend)
  
  configureCmd = ['cmake', '-S', srcDir, '-B', buildDir]
  configureCmd.append('-DCMAKE_INSTALL_PREFIX=' + installDir)
  configureCmd.append('-DCMAKE_INSTALL_MESSAGE=LAZY')
  configureCmd.append('-DKokkos_ENABLE_' + backend.upper() + '=ON')
  if not backend == 'serial':
    configureCmd.append('-DKokkos_ENABLE_SERIAL=ON')
  if backend == 'cuda':
    configureCmd.append('-DKokkos_ENABLE_CUDA_LAMBDA=ON')
      
  compileCmd = ['make', '-C', buildDir, '-j', '4', 'install']

  print('\n\t'.join(configureCmd), file=sys.stderr)
  print('\n\t' + ' '.join(compileCmd), file=sys.stderr)

  subprocess.call(configureCmd)
  subprocess.call(compileCmd)
  
  print("end compilation Kokkos ", backend, file=sys.stderr)
