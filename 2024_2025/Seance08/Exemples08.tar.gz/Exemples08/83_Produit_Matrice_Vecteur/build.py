#! /usr/bin/env python3

import os, subprocess, argparse, platform, sys

parser = argparse.ArgumentParser()
parser.add_argument('-c', '--compiler', choices=['gnu', 'intel', 'msvc'], default='gnu')
parser.add_argument('-m', '--mode', choices=['Debug', 'Release'], default='Release')
parser.add_argument('-v', '--verbose', action='store_true')
parser.add_argument('--tests', action='store_true')
args = parser.parse_args()

base       = os.getcwd()
baseSrcDir     = os.path.join(base, 'src')
baseBuildDir   = os.path.join(base, 'build')
baseInstallDir = os.path.join(base, 'install')
baseTestDir    = os.path.join(base, 'tests')

env = os.environ.copy()

p = platform.system()
gen = '-GUnix Makefiles'
env['CC'] = 'gcc'
env['CXX'] = 'g++'

def build(version, e, variante=None):
  srcDir     = os.path.join(baseSrcDir, version)
  buildDir   = os.path.join(baseBuildDir, version)
  if variante:
    buildDir = os.path.join(buildDir, variante)
  installDir = os.path.join(baseInstallDir)
  testDir    = os.path.join(baseTestDir, version)
  os.makedirs(buildDir, exist_ok=True)
  os.makedirs(testDir, exist_ok=True)

  configureCmd = ['cmake', gen, 
                  '-B', buildDir,
                  '-S', srcDir,
                  '-DCMAKE_INSTALL_PREFIX=' + installDir,
                  '-DCMAKE_BUILD_TYPE=' + args.mode,
                  '-DCMAKE_CXX_EXTENSIONS=Off',
                  '-DTEST_DIR=' + testDir]
  if variante:
    configureCmd += ['-DVariante=' + variante]
  
  if version == 'kokkos':
    configureCmd += ['-DKokkos_ROOT=' + os.path.join(base, '..', '80_Kokkos', 'install',
                                                     'kokkos_' + variante)]
     
  if args.verbose:
    compileCmd = ['make', 'VERBOSE=1', '--no-print-directory', 'install']
  else:
    compileCmd = ['make', '--no-print-directory', 'install']
  testCmd      = ['ctest', '--output-on-failure']

  commands = [
    configureCmd,
    compileCmd,
    testCmd
  ]

  for cmd in commands:
    if cmd == testCmd and not args.tests:
      continue
    print('__________________\n', ' '.join(cmd), '\n', file=sys.stderr)
    err = subprocess.call(cmd, cwd=buildDir, env=e)
    if not err==0:
      break 

build('serial', env)
build('openmp', env)
build('cuda',   env)

build('kokkos', env, 'serial')
build('kokkos', env, 'openmp')
build('kokkos', env, 'cuda')
