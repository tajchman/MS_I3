#pragma once

#include <cstddef>

class Matrix
{
public:
  Matrix(size_t p, size_t q) : _n(p), _m(q)
  {
    _data = new double[_n*_m];
  }
  ~Matrix()
  {
    delete [] _data;
  }
  size_t n() const { return _n; }
  size_t m() const { return _m; }
  double * data() { return _data; }
  const double * data() const { return _data; }
  
private:
  double * _data;
  size_t _n, _m;
};

