

#include <Kokkos_Core.hpp>
#include <cstdio>


struct InitView {
  Kokkos::View<double * [3]> a;

  InitView(Kokkos::View<double * [3]> a_) : a(a_) {}

  KOKKOS_INLINE_FUNCTION
  void operator()(const int i) const {
    a(i, 0) = 1.0 * i;
    a(i, 1) = 1.0 * i * i;
    a(i, 2) = 1.0 * i * i * i;
  }
};

struct ReduceFunctor {
  Kokkos::View<double * [3]> a;

  ReduceFunctor(Kokkos::View<double * [3]> a_) : a(a_) {}

  KOKKOS_INLINE_FUNCTION
  void operator()(int i, double& lsum) const {
    lsum += a(i, 0) * a(i, 1) / (a(i, 2) + 0.1);
  }
};

int main(int argc, char* argv[]) {
  Kokkos::initialize(argc, argv);
  {
    const int N = 10;

    Kokkos::View<double * [3]> a("A", N);

    Kokkos::parallel_for(N, InitView(a));
    double sum = 0;
    Kokkos::parallel_reduce(N, ReduceFunctor(a), sum);
    printf("Result: %f\n", sum);
  }
  Kokkos::finalize();
}
