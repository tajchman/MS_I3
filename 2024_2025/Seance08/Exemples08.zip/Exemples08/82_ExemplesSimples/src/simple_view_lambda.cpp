
#include <Kokkos_Core.hpp>
#include <cstdio>

using view_type = Kokkos::View<double * [3]>;

int main(int argc, char* argv[]) {
  Kokkos::initialize(argc, argv);

  {
    view_type a("A", 10);

    Kokkos::parallel_for(
        10, KOKKOS_LAMBDA(const int i) {
          a(i, 0) = 1.0 * i;
          a(i, 1) = 1.0 * i * i;
          a(i, 2) = 1.0 * i * i * i;
        });
    
    double sum = 0;
    Kokkos::parallel_reduce(
        10,
        KOKKOS_LAMBDA(const int i, double& lsum) {
          lsum += a(i, 0) * a(i, 1) / (a(i, 2) + 0.1);
        },
        sum);
    printf("Result: %f\n", sum);
  }
  Kokkos::finalize();
}
