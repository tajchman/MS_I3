#include <iostream>
#include <iomanip>

#include <vector>
#include "Matrix.hxx"

#include "arguments.hxx"
#include "timer.hxx"

const char *version = VERSION;

std::ostream & operator<<(std::ostream &f, const std::vector<double> &x)
{
  size_t i, n=x.size();
  for (i=0; i<n; i++)
    f << std::setw(5) << i << ": " << std::setw(10) << x[i] << std::endl;
  return f;
}

std::ostream & operator<<(std::ostream &f, const Matrix &M)
{
  size_t i, j, n=M.n(), m=M.m();
  const double *c = M.data();

  for (i=0; i<n; i++) {
    f << std::setw(5) << i << ": ";
    for (j=0; j<m; j++)
      f << std::setw(10) << c[i*m + j];
    f << std::endl;
  }
  return f;
}

void init(Matrix &M, double x1, 
          std::vector<double> &v, double x2,
          std::vector<double> &w, double x3)
{
  Timer t;
  t.start();

  size_t n = M.n(), m = M.m(), nm = n*m;
  double y1 = x1/(nm-1);
  double y2 = x2/(m-1);
  double y3 = x3/(n-1);
  double *c = M.data();
  size_t i;

  for (i=0; i<nm; i++)
    c[i] = y1 * i;

  for (i=0; i<m; i++)
    v[i] = y2 * i;

  for (i=0; i<n; i++)
    w[i] = y3 * i;

  t.stop();
  std::cout << "Initialisations : " << t.elapsed() << " s" << std::endl;
}

void matvec(std::vector<double> &w,
            const Matrix &A,
            const std::vector<double> &v)
{
  Timer t;
  t.start();

  size_t i, j, n = A.n(), m = A.m() ;
  const double *x = v.data();
  double * y = w.data();
  const double *M = A.data();
  double s;

  for (i=0;i<n; i++) {
    s = 0.0;
    for (j=0; j<m; j++)
      s += M[i*m + j] * v[j];
    w[i] = s;
  }

  t.stop();
  std::cout << "Produit matrice - vecteur : " << t.elapsed() << " s"  << std::endl;

}

double dot(const std::vector<double> &w, const std::vector<double> &v)
{
  Timer t;
  t.start();

  int i, n = v.size();
  double result = 0.0;
  for (i=0; i<n; i++)
    result += v[i] * w[i];

  t.stop();
  std::cout << "Produit scalaire vecteurs : " << t.elapsed() << " s"  << std::endl;
  return result;
}

int main(int argc, char** argv)
{
  Arguments Args(argc, argv);
  size_t n = Args.Get("n", 10000L);
  size_t m = Args.Get("m", n);

  std::cout << "version " << version << "\n\nn,m = " << n << " " << m << "\n\n";

  std::vector<double> x(m);
  std::vector<double> temp(n);
  std::vector<double> y(n);
  Matrix A(n, m);

  init(A, 2.0, x, 1.0, y, 1.5);

  matvec(temp, A, x);

  double s = dot(y, temp);

  std::cout << "\n\tyAx " << s << std::endl;

  if (n <= 10 && m <= 10) {
    std::cout << "x\n" << x << std::endl;
    std::cout << "A\n" << A << std::endl;
    std::cout << "y\n" << y << std::endl;
  }
  std::cout << "\n";
  return 0;
}
