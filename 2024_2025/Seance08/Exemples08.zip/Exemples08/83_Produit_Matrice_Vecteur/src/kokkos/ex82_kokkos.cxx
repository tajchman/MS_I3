#include <string>
#include <iostream>
#include <iomanip>

#include "Kokkos_Core.hpp"

#include "arguments.hxx"
#include "timer.hxx"

const char * version = VERSION;

std::ostream & operator<<(std::ostream &f, const Kokkos::View<double*> &x)
{
  const Kokkos::View<double*>::HostMirror h_x =
    Kokkos::create_mirror_view(x);
  Kokkos::deep_copy(h_x, x);

  size_t i, n=h_x.size();
  for (i=0; i<n; i++)
    f << std::setw(5) << i << ": " << std::setw(10) << h_x(i) << std::endl;
  return f;
}

std::ostream & operator<<(std::ostream &f, const Kokkos::View<double**> &M)
{
  const Kokkos::View<double**>::HostMirror h_M =
    Kokkos::create_mirror_view(M);
  Kokkos::deep_copy(h_M, M);
  size_t i, j, n=h_M.extent(0), m=h_M.extent(1);
 
  for (i=0; i<n; i++) {
    f << std::setw(5) << i << ": ";
    for (j=0; j<m; j++)
      f << std::setw(10) << h_M(i,j);
    f << std::endl;
  }
  return f;
}

void init(Kokkos::View<double**> &M, double x1, 
          Kokkos::View<double*> &v, double x2,
          Kokkos::View<double*> &w, double x3)
{
  Timer t;
  t.start();

  size_t n = M.extent(0), m = M.extent(1);
  
  double y1 = x1/(n*m-1);
  double y2 = x2/(m-1);
  double y3 = x3/(n-1);

  Kokkos::parallel_for("M_init", Kokkos::MDRangePolicy<Kokkos::Rank<2>>({0,0},{n,m}), 
    KOKKOS_LAMBDA ( int i, int j ) { M(i,j) = y1*(i*m+j); });

  Kokkos::parallel_for("v_init", Kokkos::RangePolicy<>(0, m), 
    KOKKOS_LAMBDA ( int i ) { v(i) = y2 * i; });

  Kokkos::parallel_for("w_init", Kokkos::RangePolicy<>(0, n), 
    KOKKOS_LAMBDA ( int i ) { w(i) = y3 * i; });

  Kokkos::fence();
  t.stop();
  std::cout << "Initialisations : " << t.elapsed() << " s" << std::endl;
}

void matvec(Kokkos::View<double*> &w,
            const Kokkos::View<double**> & M,                                  
            const Kokkos::View<double*> &v)
{
  Timer t;
  t.start();
  size_t n = M.extent(0), m = M.extent(1);

  Kokkos::parallel_for("y = Ax", Kokkos::RangePolicy<>(0, n),
    KOKKOS_LAMBDA ( int i) {
      double temp2 = 0;

      for ( int j = 0; j < m; ++j ) {
        temp2 += M( i, j ) * v( j );
      }
      w( i ) = temp2;
    });

  Kokkos::fence();
  t.stop();
  std::cout << "Produit matrice - vecteur : " << t.elapsed() << " s"  << std::endl;

}

double dot(const Kokkos::View<double*> &v, const Kokkos::View<double*> &w)
{
  Timer t;
  t.start();

  int n = v.size();
  double result = 0.0;

  Kokkos::parallel_reduce ("dot" , Kokkos::RangePolicy<>(0, n),
    KOKKOS_LAMBDA ( int i , double & s ) {
      s += v(i) * w(i);
    }, result );

  Kokkos::fence();
  t.stop();
  std::cout << "Produit scalaire vecteurs : " << t.elapsed() << " s"  << std::endl;
  return result;
}

int main(int argc, char** argv)
{
  Arguments Args(argc, argv);
  size_t n = Args.Get("n", 10000L);
  size_t m = Args.Get("m", n);

  std::cout << "version " << version << "\n\nn,m = " << n << " " << m << "\n\n";

  Kokkos::initialize(argc, argv);
  {  
    Kokkos::View<double*>  y( "y", n );
    Kokkos::View<double*>  x( "x", m );
    Kokkos::View<double**> A( "A", n, m );
    Kokkos::View<double*>  temp( "temp", n );

    init(A, 2.0, x, 1.0, y, 1.5);

    matvec(temp, A, x);
    
    double s = dot(temp, y);

    std::cout << "\n\tyAx " << s << std::endl;

    if (n <= 10 && m <= 10) {
      std::cout << "x\n" << x << std::endl;
      std::cout << "A\n" << A << std::endl;
      std::cout << "y\n" << y << std::endl;
    }
    std::cout << "\n";
  }
  Kokkos::finalize();
  return 0;
}
