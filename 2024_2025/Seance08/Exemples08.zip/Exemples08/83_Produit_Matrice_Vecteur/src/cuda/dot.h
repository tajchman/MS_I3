/*
 * Copyright 1993-2015 NVIDIA Corporation.  All rights reserved.
 *
 * Please refer to the NVIDIA end user license agreement (EULA) associated
 * with this source code for terms and conditions that govern your use of
 * this software. Any use, reproduction, disclosure, or distribution of
 * this software and related documentation outside the terms of the EULA
 * is strictly prohibited.
 *
 */

#ifndef __DOTCUDA_H__
#define __DOTCUDA_H__

#include <cstddef>

double dotCuda(unsigned long n,
	      const double *d_idata1, const double *d_idata2,
	      size_t threads,
	      size_t blocks);

#endif
