#include "Kokkos_Core.hpp"

int main(int argc, char **argv)
{
  Kokkos::initialize(argc, argv);

  Kokkos::View<double*>  x("x", 20);

  Kokkos::finalize();
  return 0;
}