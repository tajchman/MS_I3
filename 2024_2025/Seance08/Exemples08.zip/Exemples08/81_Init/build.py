#! /usr/bin/env python3

import os, subprocess, argparse, platform, sys
e = os.environ.copy()

baseDir    = os.getcwd()
srcDir     = os.path.join(baseDir, 'src')

kokkosBaseDir = os.path.normpath(os.path.join(baseDir, '..', '80_Kokkos', 'install'))

for backend in ['serial', 'openmp', 'cuda']:
  
  kokkosDir = os.path.join(kokkosBaseDir, 'kokkos_' + backend)
  e['Kokkos_DIR'] = kokkosDir
  print('__________________\nexport Kokkos_DIR =', kokkosDir)
  
  buildDir = os.path.join(baseDir, 'build', backend)
  installDir = os.path.join(baseDir, 'install', backend)
  
  configureCmd = ['cmake', '-S', srcDir, '-B', buildDir]
  configureCmd.append('-DCMAKE_INSTALL_PREFIX=' + installDir)
  configureCmd.append('-DCMAKE_INSTALL_MESSAGE=LAZY')
  configureCmd.append('-DKokkos_ENABLE_' + backend.upper() + '=ON')
  if not backend == 'serial':
    configureCmd.append('-DKokkos_ENABLE_SERIAL=ON')
  if backend == 'cuda':
    configureCmd.append('-DKokkos_ENABLE_CUDA_LAMBDA=ON')
    configureCmd.append('-DCMAKE_CXX_EXTENSIONS=Off')
      
  compileCmd = ['make', '-C', buildDir, '-j', '4', '--no-print-directory', 'install']

  print('\n\t'.join(configureCmd), file=sys.stderr)
  print('\n\t' + ' '.join(compileCmd), file=sys.stderr)


  subprocess.call(configureCmd, env=e)
  subprocess.call(compileCmd, env=e)
  
  print("end compilation ex81", backend, file=sys.stderr)
