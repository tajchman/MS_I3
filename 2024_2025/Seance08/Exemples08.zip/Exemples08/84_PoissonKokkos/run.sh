#!/bin/bash

#SBATCH --job-name=PoissonKokkos
#SBATCH --output=output.txt
#SBATCH --error=output.txt

#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --account=ams301

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --exclusive
#SBATCH --time=00:05:00

## load modules

host=`hostname`
echo $host
if [[ "x$host" == xcholesky* ]]
then
  module purge
  module load gcc/13.2.0
  module load cuda/12.4
  module load cmake
fi

## compilation

python3 build.py

## execution

N=401

for b in serial openmp cuda
do
  code=./install/PoissonKokkos_$b
  echo $code
  if [[ $b == openmp ]]
  then
    OMP_PROC_BIND=close OMP_PLACES=threads OMP_NUM_THREADS=6 $code --n $N
  else
    $code --n $N
  fi 
done


