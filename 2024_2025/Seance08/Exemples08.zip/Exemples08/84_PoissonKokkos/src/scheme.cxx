#include "scheme.hxx"
#include "parameters.hxx"
#include "version.hxx"
#include "force.hxx"
#include <cmath>

#include <sstream>
#include <iomanip>

Scheme::Scheme(Parameters &P) :
    codeName(version), m_P(P), m_u(P), m_v(P)  {

  m_t = 0.0;
  m_duv = 0.0;

  int i;
  for (i = 0; i < 3; i++)
  {
    m_n[i] = m_P.n(i);
    m_dx[i] = m_P.dx(i);
    m_xmin[i] = m_P.xmin(i);
  }

  m_dt = m_P.dt();
}

Scheme::~Scheme()
{
}

double Scheme::present()
{
  return m_t;
}

static double iteration_domaine(int imin, int imax,
                                int jmin, int jmax,
                                int kmin, int kmax,
                                double m_t, double m_dt, double * m_dx, double * m_xmin, 
                                DeviceArray d_u, DeviceArray d_v
)
{
  double lam_x = 1 / (m_dx[0] * m_dx[0]);
  double lam_y = 1 / (m_dx[1] * m_dx[1]);
  double lam_z = 1 / (m_dx[2] * m_dx[2]);
  double xmin = m_xmin[0], dx = m_dx[0];
  double ymin = m_xmin[1], dy = m_dx[1];
  double zmin = m_xmin[2], dz = m_dx[2];
  double total_sum = 0.0;
  
  auto p = Kokkos::MDRangePolicy<Kokkos::Rank<3>>(
    {imin, jmin, kmin}, {imax+1, jmax+1, kmax+1}
  );
  Kokkos::parallel_reduce(
      p, KOKKOS_LAMBDA(int i, int j, int k, double &du_sum) {
      double du1 = (-2 * d_u(i, j, k) + d_u(i + 1, j, k) + d_u(i - 1, j, k)) * lam_x
            + (-2 * d_u(i, j, k) + d_u(i, j + 1, k) + d_u(i, j - 1, k)) * lam_y
            + (-2 * d_u(i, j, k) + d_u(i, j, k + 1) + d_u(i, j, k - 1)) * lam_z;

      double x = xmin + i * dx;
      double y = ymin + j * dy;
      double z = zmin + k * dz;
      double du2 = force(x, y, z, m_t);

      double du = m_dt * (du1 + du2);
      d_v(i, j, k) = d_u(i, j, k) + du;
          
      du_sum += du > 0 ? du : -du;
    }, total_sum);

  return total_sum;
}

bool Scheme::iteration()
{

  m_duv = iteration_domaine(
      m_P.imin(0), m_P.imax(0),
      m_P.imin(1), m_P.imax(1),
      m_P.imin(2), m_P.imax(2),
      m_t, m_dt, m_dx, m_xmin, m_u.d, m_v.d);

  m_t += m_dt;
  m_u.swap(m_v);

  return true;
}

const Values & Scheme::getOutput()
{
  Kokkos::deep_copy(m_u.h, m_u.d);
  return m_u;
}

void Scheme::setInput(const Values & u)
{
  Kokkos::deep_copy(m_u.d, u.h);
}

