#include <iostream>
#include <fstream>
#include <cstring>

#include "urand.hxx"
#include "binary.hxx"
#include "arguments.hxx"

int main(int argc, char ** argv)
{
    Arguments Args(argc, argv);
    size_t i, n = Args.Get("n", 1000000L);
    
    double *u = new double[n];
    memset(u, 0, n*sizeof(double));

    #pragma omp parallel for
    for (i=0; i<n; i++)
        u[i] = urand();

    std::cout << "init" << std::endl << " ";
    writeVector("data.bin", u, n);

    delete[] u;
    return 0;
}
