#include <iostream>
#include <cstdlib>
#include <time.h>
#include <cstring>

#ifdef _OPENMP
#include <omp.h>
#endif

#include "timer.hxx"
#include "results.hxx"
#include "binary.hxx"

int main(int argc, char **argv) {

  Timer T_total, T_init, T_calcul;
  T_total.start();
  T_init.start();
  
  double moy, var;

  size_t i, n;
  double * u;
  readVector("data.bin", u, n);

  int nThreads;

  #ifdef _OPENMP
  #pragma omp parallel
  {
    #pragma omp master
    nThreads = omp_get_num_threads();
  }
  #else
    nThreads = 1;
  #endif

  std::cerr << "version 2b, " << nThreads << " thread(s)"
            << " n = " << n << " u0 = " << u[0] << " ";

  T_init.stop();
  T_calcul.start();

  double s = 0.0, s2 = 0.0;

#pragma omp parallel default (shared)
  {
    size_t i;
    int iTh;

#ifdef _OPENMP
    iTh = omp_get_thread_num();
#else
    iTh = 0;
#endif
    double s_partiel = 0.0, s2_partiel = 0.0;
#pragma omp for 
    for (i=0; i<n ; i++) {
      s_partiel += u[i];
      s2_partiel += u[i]*u[i];
    }

#pragma omp atomic
    s += s_partiel;
#pragma omp atomic
    s2 += s2_partiel;

  }

  moy = s / n;
  var = s2/n - moy*moy;

  T_calcul.stop();

  T_total.stop();

  writeResults("version2b", n, nThreads, moy, var, 
                T_init.elapsed(), T_calcul.elapsed(), T_total.elapsed());
  return 0;
}
