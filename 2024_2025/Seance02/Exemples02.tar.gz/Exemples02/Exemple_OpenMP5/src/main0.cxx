#include <iostream>
#include <cstdlib>
#include <time.h>
#include <cstring>

#include "timer.hxx"
#include "results.hxx"
#include "binary.hxx"

int main(int argc, char **argv) {

  Timer T_total, T_init, T_calcul;
  T_total.start();
  T_init.start();
  
  double moy, var;

  size_t i, n;
  double * u;
  readVector("data.bin", u, n);

  
  std::cerr << "version 0, séquentielle, "
            << " n = " << n << " u0 = " << u[0] << " ";

  T_init.stop();
  T_calcul.start();

  double s = 0.0, s2 = 0.0;

  for (i=0; i<n ; i++) {

    s += u[i];
    s2 += u[i]*u[i];
  }

  moy = s / n;
  var = s2/n - moy*moy;

  T_calcul.stop();

  T_total.stop();

  writeResults("version0", n, 1, moy, var, 
                T_init.elapsed(), T_calcul.elapsed(), T_total.elapsed());
  return 0;
}
