#include <iostream>
#include <cstdlib>
#include <time.h>
#include <cstring>

#ifdef _OPENMP
#include <omp.h>
#endif

#include "timer.hxx"
#include "results.hxx"
#include "binary.hxx"

int main(int argc, char **argv) {

  Timer T_total, T_init, T_calcul;
  T_total.start();
  T_init.start();
  
  double moy, var;

  size_t i, n;
  double * u;
  readVector("data.bin", u, n);

  int nThreads;

  #ifdef _OPENMP
  #pragma omp parallel
  {
    #pragma omp master
    nThreads = omp_get_num_threads();
  }
  #else
    nThreads = 1;
  #endif

  std::cerr << "version 1, " << nThreads << " thread(s)"
            << " n = " << n << " u0 = " << u[0] << " ";

  T_init.stop();
  T_calcul.start();

  double * s_partiel, * s2_partiel;

  int dS = 1;
  int nS = nThreads * dS, iS;

  s_partiel = new double[nS];
  s2_partiel = new double[nS];
  for (iS=0; iS < nS; iS += dS) {
    s_partiel[iS] = 0.0;
    s2_partiel[iS] = 0.0;
  }

 int iT = 0;
#pragma omp parallel for
  for (i=0; i<n ; i++) {

#ifdef _OPENMP
    iT = omp_get_thread_num() * dS;
#endif
    s_partiel[iT] += u[i];
    s2_partiel[iT] += u[i]*u[i];
  }

  delete [] u;

  double s = 0.0, s2 = 0.0;
  double * p = s_partiel, *p2 = s2_partiel;

  for (iS=0; iS < nS; iS += dS, p += dS, p2 += dS) {
    s += *p;
    s2 +=*p2;
  }

  delete [] s_partiel;
  delete [] s2_partiel;

  moy = s / n;
  var = s2/n - moy*moy;

  T_calcul.stop();

  T_total.stop();

  writeResults("version1", n, nThreads, moy, var, 
                T_init.elapsed(), T_calcul.elapsed(), T_total.elapsed());
  return 0;
}
