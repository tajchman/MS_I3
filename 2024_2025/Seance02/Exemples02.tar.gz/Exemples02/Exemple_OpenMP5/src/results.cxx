#include <iostream>
#include <fstream>
#include <string>
#include "results.hxx"

void writeResults(const char *version, int n, int nThreads, 
                  double moy, double var, 
                  double t_init, double t_calcul, double t_total)
{
    std::cout << "moyenne " << moy << " variance " << var;
    std::cout << "\n\ntemps CPU " << std::endl
              << "\tinit   : " << t_init   << " s" << std::endl
              << "\tcalcul : " << t_calcul << " s" << std::endl
              << "\ttotal  : " << t_total  << " s" << std::endl << std::endl;

    std::string fileName = version;
    fileName += '_' + std::to_string(nThreads) + ".json";
    std::ofstream json(fileName.c_str());
    json << "{\n"
         << "\t\"n\" : \"" << n << "\",\n"
         << "\t\"version\" : \"" << version << "\",\n"
         << "\t\"threads\" : \"" << nThreads << "\",\n"
         << "\t\"moyenne\" : \"" << moy << "\",\n"
         << "\t\"variance\" : \"" << var << "\",\n"
         << "\t\"temps\" : {\n"
         << "\t\t\"init\" : \"" << t_init << "\",\n"
         << "\t\t\"calcul\" : \"" << t_calcul << "\",\n"
         << "\t\t\"total\" : \"" << t_total << "\"\n"
         << "\t}\n"
         << "}";
}