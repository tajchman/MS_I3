#include <stdio.h>

int main() {

  #pragma omp parallel
  {
    printf("Bonjour\n");
  }
  
  return 0;
 }
