#include <iostream>
#include <omp.h>
#include <chrono>
#include <thread>

void pause_usec(unsigned long n)
{
  std::this_thread::sleep_for(std::chrono::microseconds(n));
}

int main() {

  #pragma omp parallel
  {
    std::cerr << " le thread  " << omp_get_thread_num() 
              << " commence" << std::endl;
    pause_usec(1000);
    std::cerr << " le thread " << omp_get_thread_num() 
              << " a fini" << std::endl;
  }
  
  return 0;
 }
