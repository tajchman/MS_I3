/*
 * Matrice.hxx
 *
 */

#ifndef MATRICE_HXX_
#define MATRICE_HXX_

#include <vector>
#include <iostream>
#include <string>

class Matrice {
public:
	Matrice(size_t n=0, size_t m=0, const char *name = "")
          : m_n(n), m_m(m), m_coefs(n*m), m_name(name){}

	void resize(size_t n, size_t m) { m_n = n; m_m = m; m_coefs.resize(m_n*m_m); }
  size_t n() const { return m_n; }
  size_t m() const { return m_m; }
	inline double operator()(size_t i,size_t j) const { return m_coefs[i*m_m + j]; }
	inline double & operator()(size_t i,size_t j) { return m_coefs[i*m_m + j]; }

  const char * name() const { return m_name.c_str(); }

protected:
  size_t m_n, m_m;
  std::vector<double> m_coefs;
  std::string m_name;
};

std::ostream & operator<<(std::ostream & f, const Matrice & A);

#endif /* MATRICE_HXX_ */
