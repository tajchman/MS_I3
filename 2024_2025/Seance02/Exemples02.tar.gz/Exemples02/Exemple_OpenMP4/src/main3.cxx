#include <iostream>
#include <cstdlib>

#include "Matrice.hxx"
#include "timer.hxx"
#include "arguments.hxx"

int main(int argc, char **argv) {
  
  Arguments Args(argc, argv);
  size_t i,n = Args.Get("n", 4096L);

  Timer T_total, T_init, T_calcul, T_verif;
  T_total.start();
  
  {
  T_init.start();
  
  Matrice A(n,n), B(n,n), C(n,n);
  size_t j, m = A.m();
  double a, b;

  T_init.stop();
  T_calcul.start();

# pragma omp parallel for default(shared) collapse(2)
    for (i=0; i<n ; i++)
      for (j=0; j<m; j++)
        C(i,j) = a*A(i,j) + b*B(i,j);

  T_calcul.stop();
  T_verif.start();

  // verification
  for (i=0; i<n ; i++)
    for (j=0; j<m; j++)
      if (std::abs(C(i,j) - (a*A(i,j) + b*B(i,j))) > 1e-12) {
        std::cerr << "erreur sur la composante " << i  << " " << j<< std::endl;
        return -1;
      }
   T_verif.stop();
  }
  T_total.stop();

//  std::cout << "temps init   CPU : " << T_init.elapsed() << " s" << std::endl;
  std::cout << "temps calcul CPU : " << T_calcul.elapsed() << " s" << std::endl;
//  std::cout << "temps verif  CPU : " << T_verif.elapsed() << " s" << std::endl;
  std::cout << std::endl;
//  std::cout << "temps total  CPU : " << T_total.elapsed() << " s" << std::endl;
  return 0;
}
