#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os, sys, argparse, time, glob
from subprocess import *
from util import *

parser = argparse.ArgumentParser()
parser.add_argument('-t', '--threads', type=int, default=1)
parser.add_argument('-n', type=int, default=1000000)
parser.add_argument('-k', type=int, default=10)
parser.add_argument('rest', nargs=argparse.REMAINDER)
args = parser.parse_args()

job = '''#!/bin/bash

#SBATCH --job-name=Ex3_OpenMP
#SBATCH --output=output_@THREADS@.txt

@ACC@

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=@THREADS@
#SBATCH --time=00:01:00

## load modules
module load gcc/10.2.0

echo
echo "OMP_NUM_THREADS=@THREADS@ ./ex_2_openmp3_1 @N@ @K@"
echo

OMP_NUM_THREADS=@THREADS@ ./ex_2_openmp3_1 @N@ @K@

echo
echo "OMP_NUM_THREADS=@THREADS@ ./ex_2_openmp3_2 @N@ @K@"
echo

OMP_NUM_THREADS=@THREADS@ ./ex_2_openmp3_2 @N@ @K@ 
'''

s = job
s = s.replace("@N@", str(args.n))
s = s.replace("@THREADS@", str(args.threads))
s = s.replace("@ACC@", queue())
s = s.replace("@K@", str(args.k))

with open('job.sh', 'w') as f:
   f.write(s)

outFile = 'output_' + str(args.threads) + '.txt'
if os.path.exists(outFile):
   os.remove('output_' + str(args.threads) + '.txt')
call(['sbatch', 'job.sh'])
