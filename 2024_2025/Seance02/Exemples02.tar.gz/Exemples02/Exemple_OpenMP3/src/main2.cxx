#include <iostream>
#include <vector>
#include <cstdlib>
#include "timer.hxx"
#include "arguments.hxx"

int main(int argc, char **argv) {

  Arguments Args(argc, argv);
  size_t i,n = Args.Get("n", 100000000L);
  int k, kmax = Args.Get("kmax", 10);

  Timer T_total, T_init, T_calcul, T_verif;
  T_total.start();
  
  std::cout << "temps init   CPU : " << std::flush;
  T_init.start();
  
  std::vector<double> u(n, 1), v(n, 2), w(n, 0);
  double a, b;

  T_init.stop();
  std::cout << T_init.elapsed() << " s" << std::endl;

  std::cout << "temps calcul CPU : " << std::flush;
  T_calcul.start();

  for (int k=0; k<kmax; k++)
  {
  #pragma omp parallel for shared (u ,v ,w ,a ,b ,n) private (i)
    for (i=0; i < n ; i++)
      w[i] = a * u[i] + b * v[i];
  }
  T_calcul.stop();
  std::cout << T_calcul.elapsed() << " s" << std::endl;

  std::cout << "temps verif  CPU : " << std::flush;
  T_verif.start();

  // verification
  for (i=0; i < n ; i++)
    if (std::abs(w[i] - a * u[i] - b * v[i]) > 1e-12) {
      std::cerr << "erreur sur la composante " << i << std::endl;
      return -1;
  }
  
  T_verif.stop();
  std::cout << T_verif.elapsed() << " s" << std::endl;

  T_total.stop();
  std::cout << std::endl;
  std::cout << "temps total  CPU : " << T_total.elapsed() << " s" << std::endl;
  return 0;
}
