#! /usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, subprocess, util

def manage():
    job = '''#! /bin/bash

#SBATCH --job-name=PoissonSeq
#SBATCH --output=output.txt
#SBATCH --error=output.txt

@ACC@

#SBATCH --ntasks=@NP@
#SBATCH --cpus-per-task=@NT@
#SBATCH --time=@RUNTIME@

## load modules

module purge
module load cmake/3.29.3
module load gcc/13.2.0

## execution
python3 ./build.py
python3 -u ./run.py @runARGS@
python3 ./plot.py
'''

    s = job
    s = s.replace("@ACC@", util.queue())

    j = util.Job()
    s = s.replace("@NP@", str(j.npMax))
    s = s.replace("@NT@", str(j.threadsMax))
    s = s.replace("@RUNTIME@", j.runtime)

    runArgs = []
    for a in j.runArgs:
      runArgs.append('--' + a)
      runArgs.append(str(j.runArgs[a]))
    s = s.replace("@runARGS@", ' '.join(runArgs))

    jobFile = 'job.sh'
    with open(jobFile, 'w') as f:
       f.write(s)

    if os.path.exists('output.txt'):
       os.unlink('output.txt')
 
    subprocess.call(['sbatch', jobFile])

if __name__ == '__main__':
    manage()
