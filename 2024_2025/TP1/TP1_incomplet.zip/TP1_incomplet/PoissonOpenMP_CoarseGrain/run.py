#! /usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, subprocess
from util import *

def manage():
    baseDir = os.getcwd()
    
    job = Job()
    c = job.commands()

    logFile = 'log_' + job.version + '.txt'
    with open(logFile, 'w') as log:
        for l in c:
            print(' '.join(l), file=sys.stderr)
            proc = subprocess.Popen(l, stdout=PIPE, stderr=STDOUT)
            while proc.poll() is None:
                text = proc.stdout.readline().decode(sys.stdout.encoding) 
                log.write(text)
                sys.stderr.write(text)

if __name__ == '__main__':
    manage()

