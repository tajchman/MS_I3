#ifndef __FONCTEURS2__
#define __FONCTEURS2__

#include <cmath>

class Foncteur3a
{
public:
  Foncteur3a(double p, double (*f)(double)) : _p(p), _f(f) {}
  double operator() (double x) const {
    return _f(_p * x);
  }

private:
  double _p;
  double (*_f)(double);
};

class Foncteur3b
{
public:
  Foncteur3b(double p1, double p2, double (*f)(double), double (*g)(double)): _p1(p1), _p2(p2), _f(f), _g(g) {}
  double operator() (double x) const {
    return _f(_p1 * x) * _g(_p2 *x);
  }
private:
  double _p1, _p2;
  double (*_f)(double);
  double (*_g)(double);
};

#endif
