#include "integrale1b.hxx"

double integrale1b(double a, double b, long n, double (*f)(double))
{
  long i;
  double s = 0;
  double dx = (b-a)/n;

  for (i=0; i<=n; i++)
    s += f(a + i*dx);
  s *= dx;

  return s;
}

