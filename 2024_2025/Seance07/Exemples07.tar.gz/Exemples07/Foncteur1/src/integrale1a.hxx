
double integrale1a(double a, double b, long n);
