
double integrale1b(double a, double b, long n, double (*f)(double));
