#include <iostream>
#include <vector>
#include <map>
#include <list>
#include <string>

#ifdef __version_1
std::ostream & operator<<(std::ostream & f, std::map<int,std::list<std::string>> & m)
{
  f << "version 1" << std::endl;
  for (std::map<int,std::list<std::string>>::iterator it = m.begin(); it != m.end(); it++) {
    f << it->first << std::endl;

    std::list<std::string> & l = it->second;
    for (std::list<std::string>::iterator jt = l.begin(); jt != l.end(); jt++)
      f << "\t" << *jt <<std::endl;
  }
  return f;
}
#endif

#ifdef __version_2
std::ostream & operator<<(std::ostream & f, std::map<int,std::list<std::string>> & m)
{
  f << "version 2" << std::endl;
  for (auto it = m.begin(); it != m.end(); it++) {
    f << it->first << std::endl;

    auto & l = it->second;
    for (auto jt = l.begin(); jt != l.end(); jt++)
      std::cout << "\t" << *jt <<std::endl; 
  }
  return f;
}
#endif

#ifdef __version_3
auto & operator<<(std::ostream & f, std::map<int,std::list<std::string>> & m)
{
  f << "version 3" << std::endl;
  for (auto it: m)
  {
    f << it.first << std::endl;

    for (auto jt: it.second)
      f << "\t" << jt << std::endl;
  }
  return f;
}
#endif

int main()
{
  // auto x;
  auto x = 3.4;
  int count = 10;

  int& countRef = count;
  auto myAuto = countRef;

  countRef = 11;
  std::cout << count << " ";

  myAuto = 12;
  std::cout << count << std::endl;

#if defined(__version_1) || defined(__version_2) || defined(__version_3)

  std::map<int,std::list<std::string>> m;
  m[1] = {"a", "b"};
  m[3] = {"x", "y", "z"};

  std::cout << m;
  
#endif

  return 0;
}

