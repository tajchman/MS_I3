#include <iostream>
#include <cmath>

#include "arguments.hxx"
#include "foncteur2.hxx"
#include "integrale2.hxx"

double a;
double f(double x)
{
  return sin(a* x);
}

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 100000L);
  double x0 = A.Get("x0", 0.0);
  double x1 = A.Get("x1", 1.0);
  
  a = 1.5;

  Foncteur2a g(1.5);
  Foncteur2b h(3.0, -4.5);

  std::cout << "intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale2(0.0, 1.0, n, f) << std::endl;

  std::cout << "intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale2(0.0, 1.0, n, g) << std::endl;

  std::cout << "intégrale approchée de sin(3x) exp(-4.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale2(0.0, 1.0, n, h) << std::endl;

  return 0;
}
