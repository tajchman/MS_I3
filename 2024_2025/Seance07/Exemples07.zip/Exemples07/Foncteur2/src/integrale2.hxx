
#include "foncteur2.hxx"

double integrale2(double a, double b, long n, double (*f)(double));

double integrale2(double a, double b, long n, const Foncteur2a & f);

double integrale2(double a, double b, long n, const Foncteur2b & f);

double integrale2(double a, double b, long n, const Foncteur2c & f);
