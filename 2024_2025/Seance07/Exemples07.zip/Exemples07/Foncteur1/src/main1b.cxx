#include <iostream>
#include <cmath>

#include "arguments.hxx"
#include "integrale1b.hxx"

double maFonction(double x)
{
  return 2*x*x;
}

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 100000000L);
  double a = A.Get("x0", 0.0);
  double b = A.Get("x1", 1.0);

  std::cout << "\nintégrale approchée de sinus entre " << a << " et " << b << ": "
            << integrale1b(a, b, n, sin) << std::endl;

  std::cout << "\nintégrale approchée de 2*x^2 entre " << a << " et " << b << ": " 
            << integrale1b(a, b, n, maFonction) << "\n" << std::endl;

  return 0;
}
